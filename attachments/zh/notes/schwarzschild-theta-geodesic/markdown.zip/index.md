---
title: '在Schwarzschild时空中关于极角的测地线方程的解的问题'
sourceTitle: '在Schwarzschild时空中关于$\theta$的测地线方程的解的问题'
date: '2026-11-12T11:00:00+08:00'
lastmod: '2026-11-12T11:00:00+08:00'
summary: '利用存在唯一性定理讨论Schwarzschild时空赤道面测地线的初值问题'
tags: ["广义相对论","Schwarzschild","测地线"]
math: true
showTableOfContents: true
draft: false
downloads:
  markdown: true
  resources: []
---

## 测地线方程

$$
\frac{\mathrm{d}^2\theta}{\mathrm{d}\tau^2}+\frac{2}{r}\frac{\mathrm{d}r}{\mathrm{d}\tau}\frac{\mathrm{d}\theta}{\mathrm{d}\tau}-\sin\theta\cos\theta\left(\frac{\mathrm{d}\phi}{\mathrm{d}\tau}\right)^2=0
$$

## 存在唯一性定理

对于一阶矢量微分方程

$$
\frac{\mathrm{d}\mathbf{y}}{\mathrm{d}t}=\mathbf{f}(t,\mathbf{y})
$$

$\mathbf{y}$为$\mathbb{R}^n$上的矢量，$\mathbf{f}$为$\mathbb{R}\times\mathbb{R}^n\to\mathbb{R}^n$上的映射，给定初值条件$\mathbf{y}(t_0)=\mathbf{y_0}$，若满足

1. $\mathbf{f}(t, \mathbf{y})$连续；
2. 满足Lipschitz条件：$||\mathbf{f}(t,\mathbf{y_1})-\mathbf{f}(t,\mathbf{y_2})||\le L||\mathbf{y_1}-\mathbf{y_2}||$，其中$L>0$为常数。

则存在唯一解$\mathbf{y}(t)$定义在某一区间上$[t_0-\delta,t_0+\delta](\delta>0)$满足初值条件。

## 由存在唯一性定理给出满足在赤道面上的解

### 满足局域存在唯一性定理的证明

对于初值条件$\theta(0)=\frac{\pi}{2},\ \frac{\mathrm{d}\theta}{\mathrm{d}\tau}(0)=0$存在一解$\theta(\tau)=\frac{\pi}{2}$，现在利用存在唯一性定理证明该解为满足初值条件的唯一解。

 将二阶导数项分离得(令$\dot{\theta}=\frac{\mathrm{d}\theta}{\mathrm{d}\tau}$其他的同理)

$$
\ddot{\theta}=-\frac{2}{r}\dot{r}\dot{\theta}+\sin\theta\cos\theta\dot{\phi}^2
$$

为了能够正常使用存在唯一性定理，我们选取矢量$\mathbf{y}=(y_1, y_2)^T\in\mathbb{R}^2$，使其分量满足$y_1=\theta,\ y_2=\dot{\theta}$。原方程转化为一阶方程组

$$
\begin{gather}
\dot{y_1}=y_2\\
\dot{y_2}=-\frac{2}{r}\dot{r}y_2+\frac{1}{2}\sin(2y_1)\dot{\phi}^2
\end{gather}
$$

验证局部Lipschitz条件：

1. $\partial\mathbf{f}/\partial y_1=(0, \cos(2y_1)\dot{\phi}^2)^T$
2. $\partial\mathbf{f}/\partial y_2=(1, -\frac{2}{r}\dot{r})^T$

在$\tau=0, y_1=\frac{\pi}{2},y_2=0$的附近选取一个有限领域，由于$r(\tau),\dot{r}(\tau),\dot{\phi}(\tau)$连续且光滑，故在局域内均有

$$
|\dot{r}|\le C_1,\quad |\dot{\phi}|\le C_2,\quad r\ge r_{min}\ge 0
$$

故

$$
\left|\frac{\partial f_2}{\partial y_1}\right|=\left|\cos(2y_1)\dot{\phi}^2\right| \le 1 \cdot C_2^2\\
\left|\frac{\partial f_2}{\partial y_2}\right|=\left|-\frac{2}{r}\dot{r}\right| \le \frac{2C_1}{r_{min}}
$$

考虑该矢量函数的Jacobi矩阵$D_\mathbf{y}\mathbf{f}$满足

$$
||D_\mathbf{y}\mathbf{f}||=\sqrt{\left(\frac{\partial f_1}{\partial y_1}\right)^2+\left(\frac{\partial f_1}{\partial y_2}\right)^2+\cdots} \le L \quad (L为某常数)
$$

故在有限区间$\mathcal{U}=[-\delta,\delta]\times\{|y_1-\frac{\pi}{2}|<\epsilon\}\times\{|y_2|<\epsilon\}$中可以满足Lipschitz条件，从而在局域上满足存在唯一性定理。

### 满足全局存在唯一性定理的证明

假设解在$[0,T]$上成立，即此时对于所有的$\tau >0$，且对于$\theta(\tau)=\frac{\pi}{2}$在$[0,t_*)$上成立，其中$t_*$满足

$$
t_*=\mathrm{sup}\{t>0|\theta(s)=\frac{\pi}{2},\forall s \in [0,t)\}
$$

即$t_*$为所有能使$\theta(\tau)=\frac{\pi}{2}$成立的$\tau$的上确界，只要$t_*<\infty$，由连续性条件：

1. $\theta(t_*)=\frac{\pi}{2}$；
2. 在$[0,t_*)$上，$\theta(\tau)=\frac{\pi}{2}$为常数，故$\dot{\theta}(\tau)=0$，由连续性可知$\dot{\theta}(t_*)=0$。

故而此时我们可以考虑初值条件为$\theta(t_*)=\frac{\pi}{2},\dot{\theta}(t_*)=0$的初值问题，由之前的讨论可以知道存在在$t_*$的某一领域$[t_*,t_*+\epsilon)$上满足$\theta(\tau)=\frac{\pi}{2}$，与$t_*$为上确界矛盾。因此$\theta(\tau)=\frac{\pi}{2}$在$\tau \ge 0$上成立。

对于$\tau<0$时，我们可以令$s=-\tau$从而将问题转化为已经解决了的$\tau \ge 0$的情况，故而可得$\theta(\tau)=\frac{\pi}{2}$在全局上成立。

## 直接从测地线方程出发

对于测地线方程

$$
\frac{\mathrm{d}^2\theta}{\mathrm{d}\tau^2}+\frac{2}{r}\frac{\mathrm{d}r}{\mathrm{d}\tau}\frac{\mathrm{d}\theta}{\mathrm{d}\tau}-\sin\theta\cos\theta\left(\frac{\mathrm{d}\phi}{\mathrm{d}\tau}\right)^2=0
$$

先看通解，我们希望对于满足方程的$\theta(\tau)$对于过$p$的大圆都应该满足上述方程，也即对于过$p$的任意大圆的方程$r(\tau),\ \phi(\tau)$，满足上述方程的$\theta(\tau)$为我们希望的通解。故而我们可以考虑

$$
\frac{\mathrm{d}\theta}{\mathrm{d}\tau}=0\\
\sin\theta\cos\theta=0
$$

即

$$
\theta=\frac{k\pi}{2},\quad k=1,2,3,\cdots
$$

此时考虑初值条件

$$
\theta(0)=\frac{\pi}{2}\\
\dot{\theta}(0)=0
$$

故而满足初值的特解为$\theta(\tau)=\frac{\pi}{2}$。
