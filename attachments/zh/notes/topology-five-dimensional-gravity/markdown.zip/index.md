---
title: 同态、同构、同胚、同伦与同调：从代数拓扑基础到五维引力
date: '2026-11-16T14:25:37+08:00'
lastmod: '2026-11-16T14:25:37+08:00'
summary: 从群论与商结构、同伦和同调出发，讨论 Chern–Gauss–Bonnet、纠缠熵，以及五维 Kaluza–Klein、规范 Chern–Simons
  与 Gauss–Bonnet 理论。
tags:
- 代数拓扑
- 同调
- 广义相对论
- AdS/CFT
math: true
showTableOfContents: true
draft: false
downloads:
  markdown: true
  pdf: true
  resources:
  - concept-tree.svg
  - equivalence-nesting.svg
---

**从代数拓扑基础到五维 KK–Gauss–Bonnet–Chern–Simons 有效理论**

原稿作者：理论物理与量子引力学习笔记（修订版）；原稿日期：2026年7月15日。

本文面向尚未系统学习群论和代数拓扑的物理系读者，详细解释同态、同构、同胚、同伦与同调，并补足正规子群、陪集、商空间、核、像、路径同伦、基本群和相对同调等必要背景。正文以同伦为中心，比较同胚、同伦等价和同调群同构的条件强弱，再说明这些结构在量子引力、AdS/CFT、弦论和全息岛中的作用。附录 A 从凸多面体的 Euler 公式出发推导 Betti 数与 Euler--Poincaré 公式；附录 B 先给出一般 Chern--Gauss--Bonnet 定理，再讨论陈类、陈数、Chern--Simons 下降关系、二维与四维 Gauss--Bonnet、纠缠熵和高导全息纠缠熵；附录 C 介绍五维 Kaluza--Klein 降维、仅含规范型 $A\wedge F\wedge F$ 的 Chern--Simons 项以及 Einstein--Gauss--Bonnet 动力学。五维规范场降到四维后统一采用 $\chi=\chi_0$、$\mathrm d\chi=0$ 的常数零模截断。

**关键词：同态；同构；同胚；同伦；同调；Euler 示性数；Chern--Simons；纠缠熵；五维引力**

## 阅读导图

<div id="fig:concept-tree-v2" style="scroll-margin-top:110px"></div>

![五个概念的纵向总览。箭头表示"由较一般的结构进入较特殊的结构"或"构造出不变量"，并不把五个名词混成同一种关系。](concept-tree.svg)

图 1：五个概念的纵向总览。箭头表示"由较一般的结构进入较特殊的结构"或"构造出不变量"，并不把五个名词混成同一种关系。

### 五个核心概念

| **中文概念** | 英文          | 简短理解                                 |
|:-------------|:--------------|:-----------------------------------------|
| **同态**     | homomorphism  | 保持指定代数运算，但允许压缩信息         |
| **同构**     | isomorphism   | 可逆的同态；在指定结构层面无损等价       |
| **同胚**     | homeomorphism | 拓扑空间范畴中的同构，保留邻近和开集结构 |
| **同伦**     | homotopy      | 两个连续映射之间的一参数连续变形         |
| **同调**     | homology      | 用阿贝尔群记录闭链模去边界链后的"洞"     |

### 代数与拓扑符号

| 符号 | 名称 | 含义 |
|:---|:---|:---|
| $N\triangleleft G$ | 正规子群 | $gNg^{-1}=N$，从而陪集乘法可良定义 |
| $G/H$ | 陪集空间 | 左陪集 $gH$ 组成的集合；$H$ 正规时才自然成为商群 |
| $X/{\sim}$ | 商空间 | 把等价关系下的等价类当成新空间中的点 |
| $X/A$ | 子空间商 | 将整个子空间 $A$ 压缩成一个点 |
| $X\setminus A$ | 集合差 | 从 $X$ 中删除 $A$，与压缩完全不同 |
| $\ker\varphi,\operatorname{im}\varphi$ | 核、像 | 被映到单位元的部分；实际到达的部分 |
| $C_k,Z_k,B_k,H_k$ | 链、闭链、边界链、同调群 | $Z_k=\ker\partial_k$，$B_k=\operatorname{im}\partial_{k+1}$，$H_k=Z_k/B_k$ |
| $\pi_1(X,x_0)$ | 基本群 | 以 $x_0$ 为基点的闭合路径按端点固定同伦分类 |

### 微分几何与特征类符号

| 符号 | 名称 | 含义 |
|:---|:---|:---|
| $TM$ | 切丛 | 把流形每一点的切空间组合成向量丛 |
| $T^{1,0}M$ | 全纯切丛 | 复流形切丛的 $(1,0)$ 部分 |
| $\Omega$ | 曲率二形式矩阵 | Levi--Civita 联络在正交标架中的曲率 |
| $e(TM)$ | Euler 类 | 切丛的最高次数特征类，其积分给 Euler 示性数 |
| $\operatorname{Pf}$ | Pfaffian | 反对称矩阵的多项式，满足 $\operatorname{Pf}(A)^2=\det A$ |
| $\mathcal E_{2n}$ | Euler 密度 | 由 $n$ 个 Riemann 张量反对称收缩得到的 $2n$ 维密度 |
| $c_k(E)$ | 第 $k$ 陈类 | 复向量丛 $E$ 的 $2k$ 次上同调特征类 |
| $\operatorname{ch}(E)$ | Chern character | $\operatorname{Tr}\exp(i\mathcal F/2\pi)$，把陈类组织成可加形式 |
| $\mathcal F$ | 丛联络曲率 | 规范联络的二形式场强 |
| $\wedge,\star$ | 外积、Hodge 对偶 | 组合微分形式；利用度规把 $p$-形式映为互补次数形式 |

## 1 群论与商结构准备

### 1.1 为什么先谈"结构"

一个数学对象通常不只是若干元素的集合，还带有附加结构。群带有乘法，向量空间带有加法和数乘，拓扑空间指定哪些子集是开集，光滑流形还规定哪些坐标变换可以微分。因此，"两个对象相同"必须先回答：我们要求保留哪一种结构？同态、同构、同胚、同伦和同调，正是在不同层次回答这个问题。

<blockquote>

**定义：群与子群**

群 $G$ 是带有二元运算的集合，满足封闭性、结合律、单位元和逆元。若 $H\subseteq G$ 在同一运算下也构成群，则写作 $H\leq G$。若任意元素交换，称为阿贝尔群（Abelian group）。

</blockquote>

整数加法群 $(\mathbb Z,+)$ 是阿贝尔群；一般可逆矩阵群 $GL(n,\mathbb R)$ 则不交换。抽象群论的意义不在于把物理对象变成符号游戏，而在于把"复合对称变换"的共同规律提取出来。例如量子态空间上的对称作用、规范变换和时空等距变换都自然形成群。

### 1.2 陪集和正规子群

给定 $H\leq G$，对 $g\in G$ 定义左陪集和右陪集

<span id="formula-1"></span>

$$
gH=\{gh\mid h\in H\},\qquad Hg=\{hg\mid h\in H\}.
\tag{1}
$$

每个陪集可以理解为把整个子群 $H$ 平移到一个新位置。两个左陪集要么完全相同，要么不相交，因此左陪集把 $G$ 分割成若干等价类。

<blockquote>

**定义：正规子群（normal subgroup）**

若对任意 $g\in G$ 都有

<span id="formula-2"></span>

$$
gNg^{-1}=N,
\tag{2}
$$

则称 $N$ 是 $G$ 的正规子群，记作 $N\triangleleft G$。等价地，任意 $g$ 都满足 $gN=Ng$。

</blockquote>

正规性不是为了让符号更漂亮，而是为了保证陪集可以相乘。若尝试定义

<span id="formula-3"></span>

$$
(g_1N)(g_2N):=(g_1g_2)N,
\tag{3}
$$

则同一个陪集可以选择不同代表元。只有 $N$ 正规时，结果才不依赖代表元的选择。

### 1.3 商空间、集合差、陪集空间和商群

这些概念都带有"除去某些信息"的直觉，但操作完全不同。

| 对象 | 构造 | 直观含义 |
|:---|:---|:---|
| $X/{\sim}$ | 等价类集合 | 把被等价关系判定为相同的点识别起来 |
| $X/A$ | 将 $A$ 视作一个等价类 | 把 $A$ 整体压缩成一个点，而不是删除 |
| $X\setminus A$ | 删除 $A$ 中的点 | 原来属于 $A$ 的点不再存在 |
| $G/H$ | 左陪集 $gH$ 的集合 | 对任意子群均存在；通常只是集合或齐性空间 |
| $G/N$ | 正规子群的陪集 | 具有良定义的陪集乘法，因而是商群 |

##### 例一：$\mathbb Z/n\mathbb Z$。

子群 $n\mathbb Z$ 在阿贝尔群 $\mathbb Z$ 中自动正规。两个整数相差 $n$ 的倍数时属于同一陪集，于是

<span id="formula-4"></span>

$$
\mathbb Z/n\mathbb Z=\{[0],[1],\ldots,[n-1]\}
\tag{4}
$$

形成模 $n$ 加法群。

##### 例二：$\mathbb R/\mathbb Z\simeq S^1$。

把相差整数的实数识别，即 $x\sim x+m$。映射 $x\mapsto e^{2\pi i x}$ 将每个等价类映到单位圆上的一点，所以直线按整数平移取商得到圆周。这是"识别"而非"截掉"整数点；$\mathbb R\setminus\mathbb Z$ 是许多开区间的并，与圆周完全不同。

##### 例三：非正规子群的陪集空间。

在置换群 $S_3$ 中取 $H=\{e,(12)\}$。由于 $(13)(12)(13)^{-1}=(23)\notin H$，$H$ 不正规。因此 $S_3/H$ 有三个左陪集，却没有由 $S_3$ 乘法自然诱导的商群结构。这正是"陪集空间"与"商群"的差别。

## 2 同态、核、像与同构

### 2.1 同态：保持运算的映射

<blockquote>

**定义：群同态（homomorphism）**

映射 $\varphi:G_1\to G_2$ 若满足

<span id="formula-5"></span>

$$
\varphi(g_1g_2)=\varphi(g_1)\varphi(g_2),
\tag{5}
$$

则称为群同态。它表达"先复合再映射"与"先映射再复合"一致。

</blockquote>

同态不要求一一对应。例如指数映射 $\varphi:\mathbb R\to U(1)$，$\varphi(x)=e^{ix}$ 满足 $\varphi(x+y)=\varphi(x)\varphi(y)$，但所有相差 $2\pi n$ 的实数映到同一点。它保持群运算，却压缩了信息。

### 2.2 像和核

像（image）是实际能够到达的目标：

<span id="formula-6"></span>

$$
\operatorname{im}\varphi=\{\varphi(g)\mid g\in G_1\}\subseteq G_2.
\tag{6}
$$

当 $\operatorname{im}\varphi=G_2$ 时，$\varphi$ 是满射。核（kernel）则记录被压缩为单位元的全部信息：

<span id="formula-7"></span>

$$
\ker\varphi=\{g\in G_1\mid \varphi(g)=e_{G_2}\}.
\tag{7}
$$

在线性映射 $T:\mathbb R^3\to\mathbb R^2$、$T(x,y,z)=(x,y)$ 中，核是 $z$ 轴。物理上可把核想成观测或约化过程看不见的方向；像则是该过程实际能产生的状态或变换。

### 2.3 为什么核必为正规子群

先验证 $\ker\varphi$ 是子群。若 $a,b\in\ker\varphi$，则

<span id="formula-8"></span>

$$
\varphi(ab^{-1})=\varphi(a)\varphi(b)^{-1}=e,
\tag{8}
$$

所以 $ab^{-1}\in\ker\varphi$。再取任意 $g\in G_1$ 和 $n\in\ker\varphi$，有

<span id="formula-9"></span>

$$
\varphi(gng^{-1})=\varphi(g)e\varphi(g)^{-1}=e.
\tag{9}
$$

因此 $gng^{-1}\in\ker\varphi$，故

<span id="formula-10"></span>

$$
\boxed{\ker\varphi\triangleleft G_1.}
\tag{10}
$$

这一步非常关键：因为核正规，我们才能把"映射无法区分的方向"取商。

### 2.4 同构和第一同构定理

<blockquote>

**定义：同构（isomorphism）**

可逆的同态称为同构，记作 $G_1\cong G_2$。它既保持运算又不丢失信息；等价地，$\ker\varphi=\{e\}$ 且 $\operatorname{im}\varphi=G_2$。

</blockquote>
<blockquote>

**定理：第一同构定理（first isomorphism theorem）**

设 $\varphi:G_1\to G_2$ 是群同态，则 $\ker\varphi\triangleleft G_1$，并且

<span id="formula-11"></span>

$$
\boxed{G_1/\ker\varphi\cong\operatorname{im}\varphi.}
\tag{11}
$$

这一定理的直观含义是：先把所有被 $\varphi$ 视为相同的元素归为一类，剩下的结构恰好就是实际像。

</blockquote>

证明思路是定义

<span id="formula-12"></span>

$$
\bar\varphi:G_1/\ker\varphi\to\operatorname{im}\varphi,
\qquad \bar\varphi(g\ker\varphi)=\varphi(g).
\tag{12}
$$

若 $g_1\ker\varphi=g_2\ker\varphi$，则 $g_2^{-1}g_1\in\ker\varphi$，所以 $\varphi(g_1)=\varphi(g_2)$，映射良定义。它显然满射；若两个陪集映到同一点，它们之差属于核，因而陪集相同，所以又是单射。

| 概念     | 保持运算 | 是否可逆   | 核与像                         |
|:---------|:---------|:-----------|:-------------------------------|
| 同态     | 是       | 不一定     | 核可非平凡，像可小于陪域       |
| 单射同态 | 是       | 在像上可逆 | $\ker\varphi=\{e\}$            |
| 满射同态 | 是       | 不一定     | $\operatorname{im}\varphi=G_2$ |
| 同构     | 是       | 是         | 核平凡且像等于陪域             |

## 3 同胚与微分同胚：定义和基本联系

<blockquote>

**定义：同胚（homeomorphism）**

拓扑空间间的映射 $f:X\to Y$ 若双射、连续且逆映射 $f^{-1}$ 也连续，则称为同胚。同胚是拓扑空间范畴中的同构。

</blockquote>

同胚允许拉伸、弯曲和非均匀缩放，但不允许撕裂、粘点、打孔或填洞。它保持连通性、紧致性、基本群、同调群和 Euler 示性数等拓扑信息。

若 $X,Y$ 是光滑流形，并且 $f$ 与 $f^{-1}$ 都光滑，则称为微分同胚（diffeomorphism）。因此

<span id="formula-13"></span>

$$
\boxed{\text{微分同胚}\Longrightarrow\text{同胚},}
\tag{13}
$$

反向一般不成立，因为拓扑结构不必决定光滑结构。在广义相对论中，微分同胚体现光滑坐标重标记不改变几何物理内容。

## 4 同伦：把连续变形看成一部电影

### 4.1 电影比喻和标准定义

<blockquote>

**定义：同伦（homotopy）**

设 $f,g:X\to Y$ 连续。若存在连续映射

<span id="formula-14"></span>

$$
\mathscr F:X\times I\to Y,\qquad I=[0,1],
\tag{14}
$$

满足 $\mathscr F(x,0)=f(x)$、$\mathscr F(x,1)=g(x)$，则称 $f$ 与 $g$ 同伦，记作 $f\simeq g$。

</blockquote>

把参数 $t$ 看成电影时间。第一帧 $\mathscr F_0=f$，最后一帧 $\mathscr F_1=g$，中间每一帧是映射 $\mathscr F_t(x)=\mathscr F(x,t)$。同伦要求整部电影连续播放，但不要求每一帧可逆。不同的点可以在中途重合，整个图形也可以被压扁到一点。

同伦映射的标准记号常写作 $H(x,t)$。为避免与同调群 $H_k(X)$ 和 Hamiltonian 混淆，以下改用 $\mathscr F(x,t)$。

### 4.2 同痕与单参数微分同胚群

同痕（isotopy）比同伦更强。粗略说，若 $\mathscr F_t$ 的每一帧都保持为嵌入；在流形自映射情形若每一帧都是微分同胚，则称为微分同胚同痕。一般同伦只要求连续，所以允许压缩和粘合；同痕不允许在中间帧丢失嵌入性或可逆性。

向量场 $\xi$ 生成的流 $\phi_t:M\to M$ 满足

<span id="formula-15"></span>

$$
\phi_0=\operatorname{id}_M,\qquad
\phi_{s+t}=\phi_s\circ\phi_t,\qquad
\frac{\mathrm d}{\mathrm dt}\phi_t(p)=\xi(\phi_t(p)).
\tag{15}
$$

它不仅每一帧都是微分同胚，还满足群律。因此

<span id="formula-16"></span>

$$
\boxed{\text{单参数微分同胚群}
\Longrightarrow\text{微分同胚同痕}
\Longrightarrow\text{同伦}.}
\tag{16}
$$

圆盘上的 $\mathscr F_t(x)=(1-t)x$ 在 $t=1$ 把所有点压到原点，是合法同伦，却不是同痕。这说明单参数微分同胚群只是理解同伦的特殊辅助例子。

### 4.3 路径、路径同伦和闭合路径

路径（path）是连续映射

<span id="formula-17"></span>

$$
\gamma:I\to X,\qquad \gamma(0)=x_0,\qquad\gamma(1)=x_1.
\tag{17}
$$

两条具有相同端点的路径 $\gamma_0,\gamma_1$ 若存在 $\mathscr F:I\times I\to X$，且

<span id="formula-18"></span>

$$
\mathscr F(s,0)=\gamma_0(s),\quad
\mathscr F(s,1)=\gamma_1(s),\quad
\mathscr F(0,t)=x_0,\quad
\mathscr F(1,t)=x_1,
\tag{18}
$$

则称它们端点固定路径同伦（path homotopy relative to endpoints）。最后两个条件防止端点在变形中滑走；否则一个闭合路径可能仅靠移动端点就被错误地消除。

当 $x_0=x_1$ 时，$\gamma$ 是闭合路径或环路（loop）。两条首尾相接的路径可拼接：

<span id="formula-19"></span>

$$
(\gamma_1*\gamma_2)(s)=
\begin{cases}
\gamma_1(2s),&0\le s\le\tfrac12,\\
\gamma_2(2s-1),&\tfrac12\le s\le1.
\end{cases}
\tag{19}
$$

反向路径为 $\gamma^{-1}(s)=\gamma(1-s)$，常值路径充当单位元。

<blockquote>

**定义：基本群（fundamental group）**

以 $x_0$ 为基点的环路按端点固定同伦分类，所得同伦类在路径拼接下形成基本群 $\pi_1(X,x_0)$。

</blockquote>

圆周上的环路按绕数分类：顺时针与逆时针给正负整数，拼接使绕数相加，因此

<span id="formula-20"></span>

$$
\boxed{\pi_1(S^1)\cong\mathbb Z.}
\tag{20}
$$

基本群一般可以非阿贝尔，因此比第一同调群保留更多"绕洞次序"的信息。

### 4.4 映射同伦和空间同伦等价

同伦首先比较映射。要比较空间，需要同伦等价（homotopy equivalence）。若存在

<span id="formula-21"></span>

$$
f:X\to Y,\qquad g:Y\to X
\tag{21}
$$

使

<span id="formula-22"></span>

$$
g\circ f\simeq\operatorname{id}_X,\qquad f\circ g\simeq\operatorname{id}_Y,
\tag{22}
$$

则写作 $X\simeq Y$。这里不要求 $f,g$ 严格互逆，只要求复合映射可以连续变形成恒等映射。

圆环 $S^1\times[0,1]$ 可沿径向收缩到中心圆周，故与 $S^1$ 同伦等价；但两者维数不同，不可能同胚。这是"同伦等价弱于同胚"的最直观例子。

## 5 同调：闭链模去边界链

### 5.1 链和边界算子

把空间切成有向的点、边、面和更高维胞腔。$k$ 维胞腔的形式整数线性组合构成链群 $C_k(X)$。边界算子

<span id="formula-23"></span>

$$
\partial_k:C_k\to C_{k-1}
\tag{23}
$$

把一个几何块送到它的有向边界。例如有向边 $[v_0v_1]$ 的边界是 $v_1-v_0$；有向三角形的边界是三条带符号的边。

<blockquote>

**定理：边界的边界为零**

对任意链复形，连续两次取边界满足

<span id="formula-24"></span>

$$
\boxed{\partial_k\partial_{k+1}=0.}
\tag{24}
$$

几何上，每条棱在一个面的边界之边界中出现两次且取向相反，因而抵消。这一恒等式保证所有边界链必为闭链。

</blockquote>

定义闭链群和边界链群

<span id="formula-25"></span>

$$
Z_k=\ker\partial_k,\qquad B_k=\operatorname{im}\partial_{k+1}.
\tag{25}
$$

由 $\partial^2=0$ 得 $B_k\subseteq Z_k$。

<blockquote>

**定义：同调群（homology group）**

第 $k$ 阶同调群为

<span id="formula-26"></span>

$$
\boxed{H_k(X)=\frac{Z_k}{B_k}
=\frac{\ker\partial_k}{\operatorname{im}\partial_{k+1}}.}
\tag{26}
$$

它把只相差一个高一维边界的闭链视为同一个同调类。

</blockquote>

直观上，闭链是"没有边界的探针"，边界链则能在空间内部填充。若一个闭合环能围成空间中的圆盘，它在 $H_1$ 中为零；若洞阻止填充，它代表非平凡同调类。

### 5.2 同伦不变性

连续映射 $f:X\to Y$ 诱导同调同态 $f_*:H_k(X)\to H_k(Y)$。这种构造保持复合：

<span id="formula-27"></span>

$$
(g\circ f)_*=g_*\circ f_*,\qquad (\operatorname{id}_X)_*=\operatorname{id}_{H_k(X)}.
\tag{27}
$$
<blockquote>

**定理：同伦不变性（homotopy invariance）**

若 $f,g:X\to Y$ 同伦，则它们诱导相同的同调映射：$f_*=g_*$。因此若 $X\simeq Y$，则对所有 $k$ 都有

<span id="formula-28"></span>

$$
\boxed{H_k(X)\cong H_k(Y).}
\tag{28}
$$

因此，同伦等价必然蕴含各阶同调群同构，从而得到二者的条件强弱关系。

</blockquote>

反向一般不成立。同调群把信息阿贝尔化，并且不记录所有乘法结构、基本群的非交换性或更高同伦信息。

### 5.3 RT/HRT 与岛中的相对同调约束

在全息纠缠熵中，边界区域 $A$ 的候选极值面 $\gamma_A$ 仅满足 $\partial\gamma_A=\partial A$ 还不够；还要求存在 bulk 区域 $r_A$，使

<span id="formula-29"></span>

$$
\partial r_A=A\cup\gamma_A
\tag{29}
$$

（取向符号略去）。这称为同调约束（homology constraint）。它排除虽然锚定于同一纠缠面、却包围错误 bulk 区域的极值面。

若极值面允许终止在 Planck brane $Q$ 上，应使用相对同调 $H_k(M,Q)$：位于 $Q$ 上的边界可在相对链群中被视为零。对辐射区域 $R$ 和膜上岛 $\mathcal I$，可写成

<span id="formula-30"></span>

$$
\partial r_R=R\cup\gamma_R\cup\mathcal I.
\tag{30}
$$

这并不意味着 $R$、$\gamma_R$ 和 $\mathcal I$ 同胚或同伦等价，而是说它们作为链共同围出一个高一维 bulk 区域。

## 6 同胚、同伦与同调的区别和联系

| 概念 | 比较对象 | 核心条件 | 是否要求中间过程可逆 | 主要保留的信息 |
|:---|:---|:---|:---|:---|
| 同胚 | 两个空间 | 存在连续双射且逆连续 | 是 | 全部拓扑结构 |
| 同伦 | 两个映射 | 存在连续的一参数映射族 | 否 | 映射的连续变形类 |
| 同伦等价 | 两个空间 | 往返复合只需同伦于恒等 | 否 | 形变收缩后仍存在的信息 |
| 同调 | 单个空间的代数不变量 | 闭链模去边界链 | 不适用 | 各维洞的阿贝尔群信息 |

必须注意：同胚是一个特殊映射；同伦是映射之间的关系；同伦等价才是空间之间的关系；同调则是从空间构造出的代数不变量。它们并不是同一种对象。

对空间对 $(X,Y)$ 而言，条件强弱为

<span id="formula-31"></span>

$$
\boxed{
\text{微分同胚}
\Longrightarrow\text{同胚}
\Longrightarrow\text{同伦等价}
\Longrightarrow\text{各阶同调群同构}.}
\tag{31}
$$

"更强"与微分形式中"恰当必闭合，但闭合未必恰当"的说法相同：满足强条件自动满足弱条件，而只满足弱条件的反例存在。

圆环与圆周同伦等价但不同胚。另一方面，二维环面 $T^2$ 与楔和 $S^1\vee S^1\vee S^2$ 都满足 $H_1\cong\mathbb Z^2$、$H_2\cong\mathbb Z$，但

<span id="formula-32"></span>

$$
\pi_1(T^2)=\mathbb Z^2,\qquad
\pi_1(S^1\vee S^1\vee S^2)=F_2,
\tag{32}
$$

后者是两个生成元的自由非阿贝尔群，所以二者不同伦等价。

## 7 在量子引力、AdS/CFT 与弦论中的位置

- 群表示 $\rho:G\to GL(\mathcal H)$ 是同态；若核非平凡，某些对称变换在态空间上不可见。

- 微分同胚刻画引力中的坐标无关性；大微分同胚和边界条件还可能携带物理荷。

- 同伦群分类涡旋、宇宙弦、磁单极、瞬子以及大规范变换的拓扑扇区。

- 同调循环支撑弦和膜的缠绕；上同调类则描述可积通量。配对 $\int_{C_p}F_p$ 把同调循环与上同调形式联系起来。

- AdS/CFT 中的 RT/HRT 同调约束选择正确纠缠楔；岛公式使用相对同调处理膜上的端点。

- 奇数维 bulk 的 Chern--Simons 项通过反常流入编码偶数维 boundary anomaly；Gauss--Bonnet 项则修改高曲率引力、中心荷和全息纠缠熵泛函。

## 8 正文总结：空间等价条件的嵌套关系

<div id="fig:equivalence-v2" style="scroll-margin-top:110px"></div>

![满足不同空间等价条件的"空间对集合"之间的嵌套关系。](equivalence-nesting.svg)

图 2：满足不同空间等价条件的"空间对集合"之间的嵌套关系。

| 一句话问题                           | 应使用的概念 |
|:-------------------------------------|:-------------|
| 映射是否保持代数运算？               | 同态         |
| 代数结构能否无损往返？               | 同构         |
| 空间是否仅靠连续可逆变形完全一致？   | 同胚         |
| 两个映射能否连续播放成同一部"电影"？ | 同伦         |
| 空间是否在形变收缩后仍等价？         | 同伦等价     |
| 空间中哪些闭链无法被高一维链填充？   | 同调         |

## 附录 A：Betti 数与 Euler 示性数

### A.1 从凸多面体的 $V-E+F=2$ 开始

<blockquote>

**定理：Euler 多面体定理**

设一个凸多面体的顶点数、棱数和面数分别为 $V,E,F$，则

<span id="formula-33"></span>

$$
\boxed{V-E+F=2.}
\tag{33}
$$

凸性保证其表面与二维球面 $S^2$ 同胚。因此，$V-E+F=2$ 是 Euler 示性数从组合计数走向拓扑不变量的起点。

</blockquote>

例如四面体有 $(V,E,F)=(4,6,4)$，立方体有 $(8,12,6)$，两者都给出 2。重要的不是恰巧算出同一个数，而是任何不改变球面拓扑的细分都不改变这个交错和。

### A.2 为什么细分不改变 Euler 示性数

若在一条棱上加入新顶点，该棱被分成两条，于是

<span id="formula-34"></span>

$$
\Delta V=1,\qquad\Delta E=1,\qquad\Delta F=0,
\tag{34}
$$

所以 $\Delta(V-E+F)=0$。若在一个面内加入对角线，把一个面分为两个，则

<span id="formula-35"></span>

$$
\Delta V=0,\qquad\Delta E=1,\qquad\Delta F=1,
\tag{35}
$$

交错和仍不变。反复使用这两种操作可把多面体表面三角剖分。删除一个面并展平为平面图后，可以逐步去掉边界三角形而保持 $V-E+F$ 的相应关系，最终归结为单个三角形。这给出定理的组合证明思路。

一般有限胞腔复形的 Euler 示性数定义为

<span id="formula-36"></span>

$$
\chi(X)=\sum_{k\ge0}(-1)^k n_k,
\tag{36}
$$

其中 $n_k$ 是 $k$ 维胞腔数。对二维多面体表面就是 $V-E+F$。

### A.3 链群和边界矩阵

选定各胞腔的取向后，边界算子可写成矩阵

<span id="formula-37"></span>

$$
D_k=[\partial_k]:C_k\to C_{k-1}.
\tag{37}
$$

矩阵的每一列记录一个 $k$-胞腔的边界如何由 $(k-1)$-胞腔线性组合而成。条件 $\partial_{k-1}\partial_k=0$ 变成

<span id="formula-38"></span>

$$
D_{k-1}D_k=0.
\tag{38}
$$

因此 $D_k$ 的像包含在 $D_{k-1}$ 的核中。

### A.4 秩--零化度定理和 Betti 数

<blockquote>

**定理：秩--零化度定理（rank--nullity theorem）**

若 $T:V\to W$ 是有限维向量空间之间的线性映射，则

<span id="formula-39"></span>

$$
\boxed{\dim V=\dim\ker T+\operatorname{rank}T.}
\tag{39}
$$

对边界矩阵 $D_k$ 应用该定理，便可计算闭链空间的维数。

</blockquote>

在系数域 $\mathbb F$ 上，第 $k$ 个 Betti 数定义为

<span id="formula-40"></span>

$$
b_k(X)=\dim_{\mathbb F}H_k(X;\mathbb F).
\tag{40}
$$

令 $n_k=\dim C_k$、$r_k=\operatorname{rank}D_k$。秩--零化度定理给出

<span id="formula-41"></span>

$$
\dim\ker D_k=n_k-r_k,\qquad
\dim\operatorname{im}D_{k+1}=r_{k+1}.
\tag{41}
$$

因为 $H_k=\ker D_k/\operatorname{im}D_{k+1}$，所以

<span id="formula-42"></span>

$$
\boxed{b_k=n_k-r_k-r_{k+1}.}
\tag{42}
$$

物理上，$b_0$ 数连通分支，$b_1$ 数独立一维循环，$b_2$ 数独立二维闭壳；更高 $b_k$ 是高维类比。

### A.5 圆周与圆盘的完整计算

用三个顶点 $v_0,v_1,v_2$ 和三条有向边 $e_0,e_1,e_2$ 表示圆周。取

<span id="formula-43"></span>

$$
\partial e_0=v_1-v_0,\qquad
\partial e_1=v_2-v_1,\qquad
\partial e_2=v_0-v_2,
\tag{43}
$$

则

<span id="formula-44"></span>

$$
D_1=\begin{pmatrix}
-1&0&1\\
1&-1&0\\
0&1&-1
\end{pmatrix},\qquad \operatorname{rank}D_1=2.
\tag{44}
$$

圆周没有二维胞腔，所以 $r_2=0$，从而

<span id="formula-45"></span>

$$
b_0=3-0-2=1,\qquad b_1=3-2-0=1.
\tag{45}
$$

这说明圆周连通且有一个独立一维洞。

现在加入一个二维面 $f$，使 $\partial f=e_0+e_1+e_2$。于是 $r_2=1$，这个面填掉了原来的闭合环：

<span id="formula-46"></span>

$$
b_0=1,\qquad b_1=3-2-1=0,\qquad b_2=1-1=0.
\tag{46}
$$

同一条边界曲线在圆周中代表洞，在圆盘中却是二维面的边界。这正体现同调依赖整个空间，而非只看曲线本身。

### A.6 球面和环面

球面 $S^2$ 可用一个 0-胞腔和一个 2-胞腔给出胞腔分解，故

<span id="formula-47"></span>

$$
(b_0,b_1,b_2)=(1,0,1),\qquad \chi(S^2)=2.
\tag{47}
$$

环面 $T^2$ 可由一个 0-胞腔、两个 1-胞腔 $a,b$ 和一个 2-胞腔组成。胞腔边界在阿贝尔化后为零，因此

<span id="formula-48"></span>

$$
(b_0,b_1,b_2)=(1,2,1),\qquad \chi(T^2)=0.
\tag{48}
$$

两个 $b_1$ 分别对应经向和纬向循环。

### A.7 Euler--Poincaré 定理

<blockquote>

**定理：Euler--Poincaré 定理**

对有限链复形，在任意系数域上都有

<span id="formula-49"></span>

$$
\boxed{\chi(X)=\sum_k(-1)^k n_k=\sum_k(-1)^k b_k.}
\tag{49}
$$

该定理把依赖胞腔分解的组合计数改写为同调不变量。

</blockquote>

把 $b_k=n_k-r_k-r_{k+1}$ 代入右端：

<span id="formula-50"></span>

$$
\begin{aligned}
\sum_k(-1)^kb_k
&=\sum_k(-1)^kn_k-
\sum_k(-1)^kr_k-
\sum_k(-1)^kr_{k+1}.
\end{aligned}
\tag{50}
$$

后两项只差一次指标平移，符号相反，完全抵消，于是只剩 $\sum(-1)^kn_k$。这说明 Euler 示性数对细分不敏感的根本原因，是链复形中边界秩成对抵消。

闭合可定向 genus-$g$ 曲面满足

<span id="formula-51"></span>

$$
b_0=b_2=1,\qquad b_1=2g,\qquad
\boxed{\chi(\Sigma_g)=2-2g.}
\tag{51}
$$

### A.8 自由部分、挠率和四维例子

整数同调群一般分解为

<span id="formula-52"></span>

$$
H_k(X;\mathbb Z)\cong\mathbb Z^{b_k}\oplus
\mathbb Z_{n_1}\oplus\cdots\oplus\mathbb Z_{n_s}.
\tag{52}
$$

$\mathbb Z^{b_k}$ 是自由部分，有限循环群是挠率（torsion）。用 $\mathbb R$ 或 $\mathbb Q$ 作系数时，挠率消失，所以 Betti 数并不能看到所有整数同调信息。

常见闭合四维流形的 Betti 数为

| $M_4$           | $b_0$ | $b_1$ | $b_2$ | $b_3$ | $b_4$ | $\chi$ |
|:----------------|:-----:|:-----:|:-----:|:-----:|:-----:|:------:|
| $S^4$           |   1   |   0   |   0   |   0   |   1   |   2    |
| $\mathbb{CP}^2$ |   1   |   0   |   1   |   0   |   1   |   3    |
| $S^2\times S^2$ |   1   |   0   |   2   |   0   |   1   |   4    |
| $T^4$           |   1   |   4   |   6   |   4   |   1   |   0    |
| K3              |   1   |   0   |  22   |   0   |   1   |   24   |

这些整数随后通过 Chern--Gauss--Bonnet 定理与曲率积分联系起来。

## 附录 B：Chern--Gauss--Bonnet、陈数与纠缠熵

### B.1 一般 Chern--Gauss--Bonnet 定理

先解释定理中的几个不常用符号。$TM$ 是切丛：纤维 $T_pM$ 是点 $p$ 的切空间。选取 Levi--Civita 联络后，其曲率可在正交标架中写成反对称矩阵值二形式 $\Omega=(\Omega^a{}_b)$。Pfaffian $\operatorname{Pf}$ 是反对称矩阵的多项式，满足 $\operatorname{Pf}(A)^2=\det A$。Euler 类 $e(TM)$ 是由曲率构造的最高次闭形式所代表的上同调类；换联络会改变代表形式，但只改变一个恰当形式，因此上同调类不变。

<blockquote>

**定理：Chern--Gauss--Bonnet 定理**

设 $M$ 是闭合、定向的 $2n$ 维 Riemann 流形，$\Omega$ 是 Levi--Civita 联络的曲率二形式矩阵，则

<span id="formula-53"></span>

$$
\boxed{\chi(M)=\int_M e(TM)
=\int_M\operatorname{Pf}\!\left(\frac{\Omega}{2\pi}\right).}
\tag{53}
$$

若 $M$ 有边界，还必须加入由第二基本形式和边界内禀曲率构成的 Chern 边界项。下文先由该定理恢复二维和四维公式，再说明 Euler 密度作为引力作用量时的维数依赖。

</blockquote>

分量形式可写成

<span id="formula-54"></span>

$$
\boxed{
\chi(M)=\frac{1}{(4\pi)^n n!}
\int_M\sqrt g\,\mathcal E_{2n}\,\mathrm d^{2n}x,}
\tag{54}
$$

其中

<span id="formula-55"></span>

$$
\mathcal E_{2n}=\frac1{2^n}
\delta^{\mu_1\cdots\mu_{2n}}_{\nu_1\cdots\nu_{2n}}
R^{\nu_1\nu_2}{}_{\mu_1\mu_2}\cdots
R^{\nu_{2n-1}\nu_{2n}}{}_{\mu_{2n-1}\mu_{2n}}.
\tag{55}
$$

广义 Kronecker delta 对上下指标分别全反对称，它迫使曲率张量以 Lovelock 型组合出现。

### B.2 物理人的直觉：局域曲率密度为何给出整数

<blockquote>

**物理直觉**

曲率是局域几何场，$\chi(M)$ 是整体拓扑整数。连续改变度规会让正曲率和负曲率在空间中重新分布，但只要没有撕裂、粘合或改变边界，Euler 密度积分不会改变。它类似"局域电荷密度积分得到守恒总荷"，只是这里的总荷由拓扑量子化。

</blockquote>

需要区分两个陈述：

1.  Chern--Gauss--Bonnet 定理说特定曲率密度在临界维数 $D=2n$ 上的积分等于拓扑数；

2.  把同一密度乘耦合常数加入引力作用量后，在临界维数的无边界纯度规变分中不产生 bulk 场方程，但在更高维会产生真正局域动力学。

因此，"Gauss--Bonnet 是拓扑项"和"Gauss--Bonnet 引力修改黑洞"并不矛盾，它们针对不同维数或边界条件。

### B.3 从 Euler 类到陈类和陈数

#### B.3.1 复向量丛与总陈类

设 $E\to M$ 是秩 $r$ 的复向量丛，$\mathcal F$ 是酉联络的曲率二形式矩阵。取约定

<span id="formula-56"></span>

$$
X=\frac{i\mathcal F}{2\pi}.
\tag{56}
$$

总陈类（total Chern class）由 Chern--Weil 构造定义为

<span id="formula-57"></span>

$$
\boxed{c(E)=\det(1+X)=1+c_1(E)+c_2(E)+\cdots+c_r(E).}
\tag{57}
$$

展开行列式得到

<span id="formula-58"></span>

$$
c_1(E)=\operatorname{Tr}X,\qquad
c_2(E)=\frac12\left[(\operatorname{Tr}X)^2-\operatorname{Tr}(X^2)\right].
\tag{58}
$$

不同教材可能把规范场取为 Hermitian 或 anti-Hermitian，因而显式的 $i$ 和整体符号会变化；只要从总陈类约定一致展开，整数陈数不受影响。

Chern character 定义为

<span id="formula-59"></span>

$$
\boxed{\operatorname{ch}(E)=\operatorname{Tr}e^X
=r+\operatorname{ch}_1(E)+\operatorname{ch}_2(E)+\cdots,}
\tag{59}
$$

其中 $\operatorname{ch}_1=c_1$、$\operatorname{ch}_2=\tfrac12(c_1^2-2c_2)$。陈类在直和下乘法，而 Chern character 在直和下加法，因此后者在指标定理和 D-brane 荷中更自然。

#### B.3.2 陈数

若 $M$ 是复维 $n$ 的闭合定向流形，且 $i_1+\cdots+i_s=n$，则

<span id="formula-60"></span>

$$
\boxed{
\int_M c_{i_1}(E)\wedge\cdots\wedge c_{i_s}(E)}
\tag{60}
$$

是陈数（Chern number）。它把局域曲率信息压缩为离散拓扑数据。对复流形的自然定向，有

<span id="formula-61"></span>

$$
\boxed{e(TM_{\mathbb R})=c_n(T^{1,0}M),}
\tag{61}
$$

所以 Euler 示性数是全纯切丛最高陈类的积分。这是 Chern--Gauss--Bonnet 与陈数之间最直接的桥梁。

##### 第一陈数。

对 $U(1)$ 线丛，物理常用实场强约定

<span id="formula-62"></span>

$$
c_1(L)=\left[\frac{F}{2\pi}\right],\qquad
\frac1{2\pi}\int_{\Sigma_2}F\in\mathbb Z.
\tag{62}
$$

它既描述 Dirac 磁单极的磁通量量子化，也描述二维能带 Berry curvature 的拓扑积分。

##### 第二陈数与瞬子。

对 $SU(N)$ 丛，$\operatorname{Tr}\mathcal F=0$，四维积分

<span id="formula-63"></span>

$$
k=\frac{1}{8\pi^2}\int_{M_4}\operatorname{Tr}(F\wedge F)\in\mathbb Z
\tag{63}
$$

在一组常用迹约定下给出瞬子数；若生成元或 $F$ 的 Hermiticity 约定不同，整体符号需相应调整。

### B.4 Chern form 与 Chern--Simons form 的下降关系

由 Bianchi 恒等式可知不变多项式 $P_{2n}(F)=\operatorname{Tr}(F^n)$ 是闭形式。局部地，它可以写成某个奇数次形式的外微分：

<span id="formula-64"></span>

$$
\boxed{P_{2n}(F)=\mathrm dQ_{2n-1}(A).}
\tag{64}
$$

$Q_{2n-1}$ 就是 Chern--Simons form。最常见的非 Abelian 三形式为

<span id="formula-65"></span>

$$
\operatorname{CS}_3(A)=\operatorname{Tr}\left(A\wedge\mathrm dA+\frac23A\wedge A\wedge A\right),
\qquad
\mathrm d\operatorname{CS}_3(A)=\operatorname{Tr}(F\wedge F).
\tag{65}
$$

对 Abelian 五维形式则有

<span id="formula-66"></span>

$$
\mathrm d(A\wedge F\wedge F)=F\wedge F\wedge F.
\tag{66}
$$
<blockquote>

**容易混淆之处**

Chern form 是偶数维、规范不变的闭形式；Chern--Simons form 是低一维、依赖联络且在规范变换下可变化边界项的形式；陈数是闭流形上陈类乘积的积分；CS 作用量还包含耦合常数和量子化条件。因此"陈数等于 CS 系数"只在特定有效理论与归一化下成立，不是一般恒等式。

</blockquote>

### B.5 量子引力、AdS/CFT 与弦论中的陈数--CS 关系

#### B.5.1 全息反常流入

考虑五维 Abelian bulk 作用量

<span id="formula-67"></span>

$$
S_{\rm CS}=\kappa\int_{M_5}A\wedge F\wedge F.
\tag{67}
$$

在小规范变换 $A\mapsto A+\mathrm d\lambda$ 下，利用 $\mathrm dF=0$ 得

<span id="formula-68"></span>

$$
\delta_\lambda S_{\rm CS}
=\kappa\int_{M_5}\mathrm d(\lambda F\wedge F)
=\kappa\int_{\partial M_5}\lambda F\wedge F.
\tag{68}
$$

在 AdS$_5$/CFT$_4$ 中，bulk 规范场边界值是 CFT 全局流的源，因此这个边界变分正好给出四维流的反常 Ward identity。更系统地说，六维 anomaly polynomial 含 $F^3$，五维 $A\wedge F\wedge F$ 是其 descent form，而四维反常方程含 $F\wedge F$。这三者次数不同，不能统称为"第二陈数"。

这就是反常流入（anomaly inflow）：bulk 本身在有边界时的非不变性，抵消或编码边界量子理论的反常。CS 系数由边界 't Hooft anomaly 系数固定，并受到大规范变换量子化的约束。参见文献[&#91;14&#93;](#ref-Clark)。

#### B.5.2 D-brane Wess--Zumino coupling 和 K-theory

D$p$-brane 世界体 $W$ 上的 Wess--Zumino coupling 可示意写为

<span id="formula-69"></span>

$$
S_{\rm WZ}=\mu_p\int_W C\wedge e^B\wedge\operatorname{ch}(E)
\wedge\sqrt{\frac{\widehat A(TW)}{\widehat A(NW)}}.
\tag{69}
$$

这里 $C$ 是 RR 势的形式和，$E$ 是 Chan--Paton 规范丛，$\widehat A$ 是 A-roof genus。展开 $\operatorname{ch}(E)$ 会出现 $C\wedge F$、$C\wedge F\wedge F$ 等耦合，因此世界体规范通量可诱导低维 D-brane charge。例如 $\int F$ 关联第一陈类，$\int\operatorname{Tr}(F\wedge F)$ 关联瞬子数和更低维 RR 荷。

不过，完整 D-brane charge 不只是单个陈数；更精确的对象是 K-theory class 或含曲率修正的 Mukai vector。该避免把"D-brane charge 等于陈数"理解得过于字面化[&#91;12&#93;](#ref-GreenHarveyMoore), [&#91;13&#93;](#ref-MinasianMoore)。

#### B.5.3 Page charge、黑洞和拓扑扇区

在含 CS 项的五维超引力中，Maxwell flux 本身通常不同时满足局域守恒、规范不变和量子化三种性质。Page charge 通过加入 $A\wedge F$ 修正获得局域守恒和量子化，但会在大规范变换下偏移。对带电旋转黑洞，这会改变荷、角动量和极端性关系。量子引力路径积分还要对不同通量和丛拓扑扇区求和，陈类正是这些扇区的离散标签之一。

<blockquote>

**物理联系**

在凝聚态中，二维 Brillouin zone 上的第一陈数

$$
C_1=\frac1{2\pi}\int_{\rm BZ}F
$$

决定整数 Hall conductivity $\sigma_{xy}=C_1e^2/h$。积分掉有能隙的物质场后，低能有效作用量出现系数与 $C_1$ 相关的三维 $A\wedge\mathrm dA$。这是陈数决定 CS 响应的典型特例；其数学核心与量子引力、弦论和全息反常中的下降关系相同，但物理语境不同。

</blockquote>

### B.6 二维 Gauss--Bonnet 和二维引力

在 $n=1$ 时，$\mathcal E_2=R^{(2)}$。闭合定向曲面满足

<span id="formula-70"></span>

$$
\boxed{\chi(M)=\frac1{4\pi}\int_M\sqrt h\,R^{(2)}\,\mathrm d^2x.}
\tag{70}
$$

若有光滑边界，加入测地曲率 $k_g$：

<span id="formula-71"></span>

$$
\boxed{\chi(M)=\frac1{4\pi}\int_M\sqrt h\,R^{(2)}\,\mathrm d^2x
+\frac1{2\pi}\int_{\partial M}k_g\,\mathrm ds,}
\tag{71}
$$

若边界有角点还要加入外转角和。

半径 $a$ 的球面满足 $R^{(2)}=2/a^2$、面积 $4\pi a^2$，因此 $\chi(S^2)=2$。平面圆盘 bulk 曲率为零，但 $k_g=1/a$，边界积分给 $\chi(D^2)=1$。平坦环面曲率为零且无边界，故 $\chi(T^2)=0$。对常负曲率 $R^{(2)}=-2/\ell^2$ 的 genus-$g>1$ 曲面，定理给出

<span id="formula-72"></span>

$$
\operatorname{Area}(\Sigma_g)=4\pi(g-1)\ell^2.
\tag{72}
$$

闭曲面上的二维 Einstein--Hilbert action 为

<span id="formula-73"></span>

$$
S_{\rm EH}^{(2)}=\frac1{16\pi G_2}\int_M\sqrt h\,R^{(2)}
=\frac{\chi(M)}{4G_2}.
\tag{73}
$$

它是拓扑数，不给普通局域引力自由度。JT gravity 通过非恒定 dilaton $\Phi$ 耦合 $\Phi(R+2/L^2)$，使曲率约束与 dilaton 方程产生非平凡动力学。

### B.7 四维 Gauss--Bonnet、Einstein manifold 与高维引力

在四维，Euler 密度为

<span id="formula-74"></span>

$$
\mathcal G_4=R_{\mu\nu\rho\sigma}R^{\mu\nu\rho\sigma}
-4R_{\mu\nu}R^{\mu\nu}+R^2,
\tag{74}
$$

闭合定向四维 Riemann 流形满足

<span id="formula-75"></span>

$$
\boxed{\chi(M_4)=\frac1{32\pi^2}\int_{M_4}\sqrt g\,\mathcal G_4\,\mathrm d^4x.}
\tag{75}
$$

若 $R_{\mu\nu}=\lambda g_{\mu\nu}$，则利用 Riemann 张量的 Weyl 分解得到

<span id="formula-76"></span>

$$
\mathcal G_4=C_{\mu\nu\rho\sigma}C^{\mu\nu\rho\sigma}+\frac16R^2.
\tag{76}
$$

$S^4$ 共形平坦且 $\chi=2$；$\mathbb{CP}^2$ 的 Fubini--Study metric 是 Einstein metric 且 $\chi=3$；K3 可 Ricci-flat 但 Weyl curvature 非零，故仍有 $\chi=24$。

<blockquote>

**定理：Lovelock 二阶性质**

在给定维数中，由度规和 Riemann 张量构造、且度规场方程至多含二阶导数的自然对称守恒张量由 Lovelock densities 生成。二阶 Lovelock density 正是 Gauss--Bonnet combination $\mathcal G_D$。因此，这一特殊的曲率平方组合不会产生一般高导理论中的 ghost 型场方程。

</blockquote>

Einstein--Gauss--Bonnet action 为

<span id="formula-77"></span>

$$
S=\frac1{16\pi G_D}\int\sqrt{-g}
\left(R-2\Lambda+\alpha\mathcal G_D\right)\mathrm d^Dx.
\tag{77}
$$

在 $D=4$ 的纯度规无边界理论中，$\int\mathcal G_4$ 是拓扑项；在 $D\ge5$ 中它修改局域场方程。边界、非平凡耦合函数或某些正则化极限需要另行分析，不能简单套用"四维拓扑项"的结论。

### B.8 纠缠熵：从约化密度矩阵到 replica trick

以下讨论主要遵循 Nishioka 的综述[&#91;4&#93;](#ref-Nishioka)，并保留其中的英文专有名词。设总 Hilbert space 二分为

<span id="formula-78"></span>

$$
\mathcal H=\mathcal H_A\otimes\mathcal H_{\bar A}.
\tag{78}
$$

这称为二分纠缠（bipartite entanglement）。对总密度矩阵 $\rho$，对补区域取偏迹得到约化密度矩阵（reduced density matrix）

<span id="formula-79"></span>

$$
\rho_A=\operatorname{Tr}_{\bar A}\rho,\qquad \operatorname{Tr}_A\rho_A=1.
\tag{79}
$$

纠缠熵（entanglement entropy）是 von Neumann entropy

<span id="formula-80"></span>

$$
\boxed{S_A=-\operatorname{Tr}_A(\rho_A\log\rho_A).}
\tag{80}
$$

若总态纯，则 $S_A=S_{\bar A}$；它测量 $A$ 与补系统之间的量子关联，而不是 $A$ 自身的热力学混合程度。

#### B.8.1 Rényi entropy 和已归一化公式

Rényi entropy 定义为

<span id="formula-81"></span>

$$
\boxed{S_n(A)=\frac{1}{1-n}\log\operatorname{Tr}_A(\rho_A^n),}
\tag{81}
$$

其中整数 $n$ 称为复制参数（replica parameter）。在假定可以从整数 $n$ 解析延拓（analytic continuation）到 $n=1$ 邻域后，

<span id="formula-82"></span>

$$
\boxed{S_A=\lim_{n\to1}S_n(A)
=-\operatorname{Tr}_A(\rho_A\log\rho_A).}
\tag{82}
$$

因为 $\operatorname{Tr}\rho_A=1$，还可写为

<span id="formula-83"></span>

$$
\boxed{S_A=-\left.\partial_n\log\operatorname{Tr}_A(\rho_A^n)\right|_{n=1}.}
\tag{83}
$$

归一化条件不可省略；若直接把未归一化路径积分对象代入最后一式，会漏掉 $Z_1^n$。

#### B.8.2 QFT 路径积分中的 replica trick

在 Euclidean QFT 中，沿纠缠区域（entangling region）$A$ 切开时空，把 $n$ 份切开的流形循环粘合，得到 $n$ 重覆盖（$n$-fold cover）$M_n$。其分支位置是纠缠面（entangling surface）$\Sigma=\partial A$。设原流形的 partition function 为 $Z_1\equiv Z$，$M_n$ 上的 partition function 为 $Z_n$，则

<span id="formula-84"></span>

$$
\boxed{\operatorname{Tr}_A(\rho_A^n)=\frac{Z_n}{Z_1^n}.}
\tag{84}
$$

所以正确的 Rényi entropy 公式链为

<span id="formula-85"></span>

$$
\boxed{
S_n(A)=\frac{1}{1-n}\left(\log Z_n-n\log Z_1\right)
=\frac{1}{1-n}\log\frac{Z_n}{Z_1^n}.}
\tag{85}
$$

取 $n\to1$ 得复制技巧（replica trick）

<span id="formula-86"></span>

$$
\boxed{
S_A=-\left.\partial_n\left(\log Z_n-n\log Z_1\right)\right|_{n=1}.}
\tag{86}
$$

在 $Z_1$ 是固定原流形 partition function 的前提下，等价写成

<span id="formula-87"></span>

$$
\boxed{S_A=\left.(1-\partial_n)\log Z_n\right|_{n=1}.}
\tag{87}
$$
<blockquote>

**容易混淆之处**

$\operatorname{Tr}\rho_A^n$、$Z_n$ 和 $Z_n/Z_1^n$ 是三个不同对象。第一项已归一化；第二项是分支覆盖上的未归一化 partition function；第三项才与第一项相等。因此，replica trick 的路径积分公式必须始终保留 $Z_1^n$，否则会产生归一化错误。

</blockquote>

### B.9 面积律、普适项与 CFT

局域 QFT 的基态纠缠主要来自纠缠面两侧的短程关联，因而出现面积律（area law）

<span id="formula-88"></span>

$$
S_A=\sum_{j=1}^{d-2}\frac{c_j}{\epsilon^j}
+\begin{cases}
c_{\log}\log(R/\epsilon)+\cdots,&d\ \text{偶},\\
F+\cdots,&d\ \text{奇},
\end{cases}
\tag{88}
$$

其中 $\epsilon$ 是 UV cutoff。幂次发散依赖正则化方案；偶数维的 logarithmic universal term 与 conformal anomaly 相关，奇数维的有限 universal term 则可在适当条件下定义 scheme-independent quantity。球形纠缠面（spherical entangling surface）的普适项尤其直接地读取 CFT central charges，并与 renormalization group flow 的 $C$-theorem 或 $F$-theorem 联系[&#91;4&#93;](#ref-Nishioka)。

### B.10 holographic entanglement entropy

#### B.10.1 GKP--W relation 与全息 replica 表示

GKP--W relation 把边界 generating functional 与 bulk on-shell action 联系：

<span id="formula-89"></span>

$$
Z_{\rm CFT}[M]=e^{-I_{\rm bulk}[B]}.
\tag{89}
$$

令 $B_n$ 是边界为 $M_n$ 的光滑 bulk replica geometry，$B_1=B$。将 $\log Z_n=-I_{\rm bulk}[B_n]$ 代入上节公式得到

<span id="formula-90"></span>

$$
\boxed{
S_A=\left.\partial_n\left[I_{\rm bulk}[B_n]
-nI_{\rm bulk}[B_1]\right]\right|_{n=1}.}
\tag{90}
$$

这一步除 analytic continuation 外，经典推导通常还假定 replica symmetry。光滑 $B_n$、其 orbifold

<span id="formula-91"></span>

$$
\widehat B_n=B_n/\mathbb Z_n
\tag{91}
$$

以及有锥缺陷的 $\widehat B_n$ 不能混淆：锥缺陷位于延伸自 $\Sigma$ 的 codimension-two fixed locus。

#### B.10.2 Ryu--Takayanagi formula 与 HRT formula

<blockquote>

**定理：Ryu--Takayanagi formula**

在由经典 Einstein gravity 描述的静态 asymptotically AdS bulk 中，边界区域 $A$ 的 leading large-$N$ entanglement entropy 为

<span id="formula-92"></span>

$$
\boxed{S_A=\frac{\operatorname{Area}(\gamma_A)}{4G_N},}
\tag{92}
$$

其中 $\gamma_A$ 是与 $A$ 同调、满足 $\partial\gamma_A=\partial A$ 的最小 codimension-two surface[&#91;5&#93;](#ref-RT)。

</blockquote>

时间依赖情形使用 Hubeny--Rangamani--Takayanagi formula（HRT formula）：把同一边界和同调条件下的最小面替换为 Lorentzian extremal surface，并在多个极值面中选择适当的最小广义熵分支[&#91;6&#93;](#ref-HRT)。因此"极值"解决局部变分条件，"同调约束"选择正确的全局拓扑类。

Lewkowycz--Maldacena replica derivation 的核心是：$n\to1$ 时 orbifold 锥缺陷等效于张力趋于零的 cosmic brane，其作用量对 $n$ 的导数留下面积项[&#91;7&#93;](#ref-LM)。

#### B.10.3 Rényi entropy 与 cosmic brane

定义模 entropy（modular entropy）

<span id="formula-93"></span>

$$
\widetilde S_n=n^2\partial_n\left(\frac{n-1}{n}S_n\right).
\tag{93}
$$

在 Einstein gravity 中，它由反作用后的 cosmic brane 面积给出

<span id="formula-94"></span>

$$
\widetilde S_n=\frac{\operatorname{Area}(\mathcal C_n)}{4G_N}.
\tag{94}
$$

与 $n=1$ 的 RT surface 不同，$n\neq1$ 时 cosmic brane 具有有限张力并反作用 bulk geometry。

#### B.10.4 spherical region 与 hyperbolic black hole

对 CFT 真空中的球形区域，共形变换把约化密度矩阵映到双曲空间上的 thermal density matrix。bulk 中 RT surface 映到 hyperbolic AdS black hole horizon，因此

<span id="formula-95"></span>

$$
S_A^{\rm sphere}=S_{\rm thermal}(\mathbb H^{d-1})=S_{\rm BH}^{\rm hyperbolic}.
\tag{95}
$$

这是一般 entangling surface 与黑洞 horizon 不同、但球形情形二者可以等同的特殊机制。它也解释了球形 universal term 与 central charge、RG monotonicity 的紧密联系。

### B.11 Gauss--Bonnet 引力中的全息纠缠熵

Wald entropy 适用于 stationary Killing horizon，但一般 RT/HRT surface 并非 Killing horizon。对一般 higher derivative gravity，replica geometry 还产生依赖 extrinsic curvature 的修正。Dong functional 和 Camps functional 系统地给出这些项[&#91;8&#93;](#ref-Dong), [&#91;9&#93;](#ref-Camps)。

<blockquote>

**定理：Lovelock/Gauss--Bonnet 的 Jacobson--Myers functional**

对 Lovelock gravity，higher derivative holographic entanglement entropy functional 化为 Jacobson--Myers type functional。对 Gauss--Bonnet action，在常用归一化和忽略 regulator boundary term 时

<span id="formula-96"></span>

$$
\boxed{
S_{\rm JM}[\Sigma]=\frac1{4G_D}\int_\Sigma\sqrt h
\left(1+2\alpha\mathcal R_\Sigma\right)\mathrm d^{D-2}y,}
\tag{96}
$$

其中 $\mathcal R_\Sigma$ 是 codimension-two surface 的内禀标量曲率；物理解是使该泛函极值的曲面[&#91;10&#93;](#ref-JM), [&#91;8&#93;](#ref-Dong), [&#91;9&#93;](#ref-Camps)。

</blockquote>

需要区分：stationary black hole entropy 是 horizon 上的 Noether-charge/Jacobson--Myers entropy；一般 holographic entanglement entropy 在与 $A$ 同调的极值曲面上计算；只有 spherical region 映到 hyperbolic black hole 时，两种描述直接重合。

在 AdS$_5$/CFT$_4$ 中，Gauss--Bonnet coupling 改变有效 AdS radius、boundary central charges $a,c$ 的关系、球形 entanglement entropy 的 universal logarithmic term 以及 holographic RG flow。由于高导耦合还受 causality、unitarity 和 UV completion 约束，不能只把 $\alpha$ 当作任意大的现象学参数。

## 附录 C：五维 Kaluza--Klein、规范 Chern--Simons 与 Gauss--Bonnet 理论

### C.1 范围和约定

以下五维模型只包含 Abelian 规范 Chern--Simons term

<span id="formula-97"></span>

$$
A\wedge F\wedge F,
\tag{97}
$$

不把 $A\wedge\operatorname{Tr}(R\wedge R)$ 或纯引力 CS form 加入作用量。附录 B 为解释 descent relation 提及的非 Abelian 或引力例子不属于这一具体模型。

五维规范场降到四维时，先保留动态零模 $\chi(x)$ 并完成代数展开；完成动态降维后，再在明确标出的截断点取

<span id="formula-98"></span>

$$
\boxed{\chi(x)=\chi_0,\qquad\mathrm d\chi=0.}
\tag{98}
$$

### C.2 KK 理论的几何思想和模展开

Kaluza--Klein theory（KK theory）的核心是把高维几何沿紧致内部空间展开成低维场。取

<span id="formula-99"></span>

$$
M_5=M_4\times S^1,\qquad y\sim y+2\pi R.
\tag{99}
$$

任意五维场都可以 Fourier 展开：

<span id="formula-100"></span>

$$
\Phi(x,y)=\sum_{n\in\mathbb Z}\Phi_n(x)e^{iny/R},
\qquad m_n^2=m_0^2+\frac{n^2}{R^2}.
\tag{100}
$$

低能 $E\ll R^{-1}$ 时，有质量的 $n\neq0$ KK modes 难以激发，常采用 zero-mode truncation。

五维 metric ansatz 可取

<span id="formula-101"></span>

$$
\mathrm ds_5^2=e^{-2\phi/\sqrt3}g_{\mu\nu}\mathrm dx^\mu\mathrm dx^\nu
+e^{4\phi/\sqrt3}(\mathrm dy+2C_\mu\mathrm dx^\mu)^2.
\tag{101}
$$

其中 $g_{\mu\nu}$ 是四维 Einstein-frame metric，$\phi$ 是 radion/dilaton，$C_\mu$ 是 KK gauge field。局域坐标变换

<span id="formula-102"></span>

$$
y\mapsto y-2\lambda(x)
\tag{102}
$$

诱导 $C\mapsto C+\mathrm d\lambda$。因此四维 $U(1)$ gauge symmetry 源于五维沿圆周方向的 diffeomorphism。

忽略归一化细节，五维 Einstein--Hilbert term 降为

<span id="formula-103"></span>

$$
S_4\sim\int\sqrt{-g}\left[R-2(\partial\phi)^2
-e^{-2\sqrt3\phi}G_{\mu\nu}G^{\mu\nu}\right]\mathrm d^4x,
\qquad G=\mathrm dC.
\tag{103}
$$

这展示了高维 metric 如何统一产生低维 metric、scalar 和 gauge field。

### C.3 五维 Abelian gauge Chern--Simons term

取独立的五维 Abelian gauge field $A$，$F=\mathrm dA$。规范 CS action 写为

<span id="formula-104"></span>

$$
\boxed{S_{\rm CS}=\frac{\kappa}{3}\int_{M_5}A\wedge F\wedge F.}
\tag{104}
$$

系数 $1/3$ 是一种方便约定；与 Maxwell term 合并时，$\kappa$ 的具体数值依赖整体 action normalization。

<blockquote>

**定理：Stokes 定理**

若 $M$ 是定向流形、$\omega$ 是次数合适的光滑微分形式，则

<span id="formula-105"></span>

$$
\boxed{\int_M\mathrm d\omega=\int_{\partial M}\omega.}
\tag{105}
$$

Stokes 定理把 CS action 的 gauge variation 化为 boundary term。

</blockquote>

在 $A\mapsto A+\mathrm d\lambda$ 下，

<span id="formula-106"></span>

$$
\begin{align}
\delta_\lambda S_{\rm CS}
&=\frac{\kappa}{3}\int_{M_5}\mathrm d\lambda\wedge F\wedge F\tag{106}\\
&=\frac{\kappa}{3}\int_{\partial M_5}\lambda F\wedge F.
\tag{107}
\end{align}
$$

闭合流形上小规范变换不改变 action；有边界时该项产生 anomaly inflow。大规范变换还会约束 $\kappa$ 的量子化，具体单位取决于最小电荷和 gauge group normalization。

### C.4 Maxwell--CS equation 与 Page charge

考虑

<span id="formula-108"></span>

$$
S[A]=-\frac12\int F\wedge\star F
+\frac{\kappa}{3}\int A\wedge F\wedge F.
\tag{108}
$$

对 $A$ 变分并忽略边界项，得到

<span id="formula-109"></span>

$$
\boxed{\mathrm d\star F+\kappa F\wedge F=0,\qquad \mathrm dF=0.}
\tag{109}
$$

纯规范 CS term 不显含 metric，所以没有直接 stress tensor；但它改变 $F$ 的解，继而通过 Maxwell stress tensor 间接反作用 geometry。

方程可改写为

<span id="formula-110"></span>

$$
\mathrm d(\star F+\kappa A\wedge F)=0.
\tag{110}
$$

因此 Page form $\star F+\kappa A\wedge F$ 局域闭合，相应 Page charge 在合适 cycle 上守恒且通常量子化；但它显含 $A$，所以在大规范变换下可能偏移。Maxwell charge 较规范不变，却会因 bulk 的 $F\wedge F$ 而在不同曲面间流动。选择何种 charge 必须与研究的问题一致。

### C.5 五维规范场降到四维：先保留动态 $\chi$

定义 KK-invariant one-form

<span id="formula-111"></span>

$$
\eta=\mathrm dy+C,\qquad G=\mathrm dC,\qquad \mathrm d\eta=G.
\tag{111}
$$

把五维独立 gauge field 写成

<span id="formula-112"></span>

$$
\mathcal A=B+\chi\eta.
\tag{112}
$$

其 field strength 为

<span id="formula-113"></span>

$$
\mathcal F=\mathrm d\mathcal A
=\widehat F+\mathrm d\chi\wedge\eta,\qquad
\widehat F=\mathrm dB+\chi G.
\tag{113}
$$

这里 $B$ 是四维 one-form，$\chi=\mathcal A_y$ 是 Wilson-line/axion-like scalar。注意动态 $\chi$ 时

<span id="formula-114"></span>

$$
\mathrm d\widehat F=\mathrm d\chi\wedge G,
\tag{114}
$$

所以 $\widehat F$ 不是独立闭合 field strength。

由于四维 base 上不存在非零五形式，只保留含一个 $\eta$ 的项：

<span id="formula-115"></span>

$$
\begin{aligned}
\mathcal A\wedge\mathcal F\wedge\mathcal F
=\Bigl[\chi\widehat F\wedge\widehat F
+2B\wedge\widehat F\wedge\mathrm d\chi\Bigr]\wedge\eta.
\end{aligned}
\tag{115}
$$

沿 $S^1$ 积分得到

<span id="formula-116"></span>

$$
\boxed{
\int_{M_5}\mathcal A\wedge\mathcal F\wedge\mathcal F
=2\pi R\int_{M_4}\left[
\chi\widehat F\wedge\widehat F
+2B\wedge\widehat F\wedge\mathrm d\chi\right].}
\tag{116}
$$

这一步展示了动态 axion 与 gauge fields 的导数耦合；归一化和全微分重排取决于四维变量选择。

### C.6 常数零模截断 $\chi=\chi_0$

从本节开始使用常数零模截断

<span id="formula-117"></span>

$$
\boxed{\chi(x)=\chi_0,\qquad\mathrm d\chi=0,\qquad
\widehat F=\mathrm dB+\chi_0G.}
\tag{117}
$$

于是

<span id="formula-118"></span>

$$
S_{\rm CS}^{(4)}\propto
2\pi R\,\kappa\chi_0
\int_{M_4}\widehat F\wedge\widehat F.
\tag{118}
$$

这是四维 theta-type topological term。在闭合 bulk 且 $\chi_0$ 固定时，它不改变局域 Maxwell equation；但可影响 boundary term、量子相位、topological sector，并混合 $B$ 与 KK gauge field $C$。常数零模截断下不再包含 $\mathrm d\chi$ 相互作用。

### C.7 五维 Einstein--Gauss--Bonnet 动力学

五维 action 为

<span id="formula-119"></span>

$$
S_{\rm EGB}^{(5)}=\frac1{16\pi G_5}
\int\sqrt{-g}\left(R-2\Lambda+\alpha\mathcal G_5\right)\mathrm d^5x,
\tag{119}
$$

其中

<span id="formula-120"></span>

$$
\mathcal G_5=R_{MNRS}R^{MNRS}-4R_{MN}R^{MN}+R^2.
\tag{120}
$$

在五维它不再是拓扑项。场方程为

<span id="formula-121"></span>

$$
G_{MN}+\Lambda g_{MN}+\alpha H_{MN}=8\pi G_5T_{MN},
\tag{121}
$$

其中 Lanczos tensor

<span id="formula-122"></span>

$$
\begin{align}
H_{MN}={}&2\Bigl(RR_{MN}-2R_{MP}R^P{}_N
-2R^{PQ}R_{MPNQ}
+R_M{}^{PQR}R_{NPQR}\Bigr)\tag{122}\\
&-\frac12g_{MN}\mathcal G_5.
\tag{123}
\end{align}
$$

尽管 action 含曲率平方，Lovelock 组合使场方程仍至多含 metric 的二阶导数。

对常曲率 ansatz

<span id="formula-124"></span>

$$
R_{MNRS}=K(g_{MR}g_{NS}-g_{MS}g_{NR}),
\tag{124}
$$

真空方程化为

<span id="formula-125"></span>

$$
\boxed{K+2\alpha K^2=\frac{\Lambda}{6}}
\tag{125}
$$

（符号随 Riemann convention 而变）。二次方程产生连续连接 $\alpha\to0$ Einstein branch 和另一条 non-Einstein branch；后者常涉及不同有效 Newton constant 或稳定性问题。

### C.8 EGB--Maxwell--CS 总作用量

一个方便的组合模型是

<span id="formula-126"></span>

$$
\boxed{
S_5=\frac1{16\pi G_5}\int_{M_5}\left[
(R-2\Lambda+\alpha\mathcal G_5)\star1
-\frac12F\wedge\star F
+\frac{\kappa}{3}A\wedge F\wedge F\right].}
\tag{126}
$$

Gauss--Bonnet term 直接修改 gravitational equation、AdS radius、black hole geometry 和 entropy functional；规范 CS term 直接修改 gauge equation 和 Page charge，但无直接 metric stress tensor。两者通过共同解出的 $F$、metric 和 Hodge star 间接耦合。

### C.9 黑洞、熵与 AdS$_5$/CFT$_4$

五维 Gauss--Bonnet black hole 的 stationary horizon entropy 使用 Jacobson--Myers/Wald-type formula，而非纯面积律：

<span id="formula-127"></span>

$$
S_{\rm BH}=\frac1{4G_5}\int_{\mathcal H}\sqrt h
\left(1+2\alpha\mathcal R_{\mathcal H}\right)\mathrm d^3y.
\tag{127}
$$

规范 CS coupling 改变 charged rotating black hole 的 charge--angular momentum relation、Page charge 和 extremal branches[&#91;16&#93;](#ref-Gauntlett), [&#91;17&#93;](#ref-Kunz)。

在 AdS$_5$/CFT$_4$ 中，bulk gauge CS coefficient 编码 boundary global-current anomaly coefficient；Gauss--Bonnet coupling 改变 boundary central charges 和 holographic entanglement entropy。若模型来自 supersymmetric string compactification，$\alpha$、$\kappa$ 和其他 higher derivative couplings 往往受 supersymmetry、flux quantization 和 anomaly matching 共同约束，不能任意独立选择。

### C.10 四维有效结构和适用范围

五维 Gauss--Bonnet term 做 KK reduction 后，若完全冻结 radion 和 KK gauge field，仅留下四维纯 metric GB integral，它是拓扑项；若保留 $\phi$ 和 $C_\mu$，会产生

<span id="formula-128"></span>

$$
e^{a\phi}\mathcal G_4,\qquad
G^{\mu\nu}\partial_\mu\phi\partial_\nu\phi,\qquad
(\partial\phi)^2\Box\phi,\qquad
RF_C^2,\qquad F_C^4,\ldots
\tag{128}
$$

等 scalar--tensor 和 vector--tensor interactions，属于 Horndeski/Galileon-type second-order structures 的来源之一[&#91;15&#93;](#ref-Acoleyen)。

与此同时，常数 $\chi_0$ 的规范 CS reduction 只保留

<span id="formula-129"></span>

$$
\chi_0(\mathrm dB+\chi_0G)\wedge(\mathrm dB+\chi_0G),
\tag{129}
$$

不再含 $\mathrm d\chi$。因此四维局域动力学主要由 Einstein--Maxwell--dilaton 和 GB reduction 的高导耦合控制；常数 CS zero mode 主要选择 topological sector 和 boundary response。

## 参考资料

1.  <span id="ref-Hatcher"></span>

    A. Hatcher, *Algebraic Topology*, Cambridge University Press, 2002.

2.  <span id="ref-Nakahara"></span>

    M. Nakahara, *Geometry, Topology and Physics*, 2nd ed., CRC Press, 2003.

3.  <span id="ref-ChernSimons"></span>

    S.-S. Chern and J. Simons, "Characteristic forms and geometric invariants," *Ann. Math.* **99** (1974) 48--69.

4.  <span id="ref-Nishioka"></span>

    T. Nishioka, "Entanglement entropy: holography and renormalization group," *Rev. Mod. Phys.* **90** (2018) 035007, arXiv:1801.10352.

5.  <span id="ref-RT"></span>

    S. Ryu and T. Takayanagi, "Holographic derivation of entanglement entropy from AdS/CFT," *Phys. Rev. Lett.* **96** (2006) 181602, arXiv:hep-th/0603001.

6.  <span id="ref-HRT"></span>

    V. E. Hubeny, M. Rangamani and T. Takayanagi, "A covariant holographic entanglement entropy proposal," *JHEP* 07 (2007) 062, arXiv:0705.0016.

7.  <span id="ref-LM"></span>

    A. Lewkowycz and J. Maldacena, "Generalized gravitational entropy," *JHEP* 08 (2013) 090, arXiv:1304.4926.

8.  <span id="ref-Dong"></span>

    X. Dong, "Holographic entanglement entropy for general higher derivative gravity," *JHEP* 01 (2014) 044, arXiv:1310.5713.

9.  <span id="ref-Camps"></span>

    J. Camps, "Generalized entropy and higher derivative gravity," *JHEP* 03 (2014) 070, arXiv:1310.6659.

10. <span id="ref-JM"></span>

    T. Jacobson and R. C. Myers, "Black hole entropy and higher curvature interactions," *Phys. Rev. Lett.* **70** (1993) 3684.

11. <span id="ref-Lovelock"></span>

    D. Lovelock, "The Einstein tensor and its generalizations," *J. Math. Phys.* **12** (1971) 498.

12. <span id="ref-GreenHarveyMoore"></span>

    M. B. Green, J. A. Harvey and G. Moore, "I-brane inflow and anomalous couplings on D-branes," *Class. Quant. Grav.* **14** (1997) 47, arXiv:hep-th/9605033.

13. <span id="ref-MinasianMoore"></span>

    R. Minasian and G. Moore, "K-theory and Ramond--Ramond charge," *JHEP* 11 (1997) 002, arXiv:hep-th/9710230.

14. <span id="ref-Clark"></span>

    T. E. Clark, S. T. Love and T. ter Veldhuis, "Holographic currents and Chern--Simons terms," arXiv:1006.2400.

15. <span id="ref-Acoleyen"></span>

    K. Van Acoleyen and J. Van Doorsselaere, "Galileons from Lovelock actions," *Phys. Rev. D* **83** (2011) 084025, arXiv:1102.0487.

16. <span id="ref-Gauntlett"></span>

    J. P. Gauntlett *et al.*, "All supersymmetric solutions of minimal supergravity in five dimensions," *Class. Quant. Grav.* **20** (2003) 4587, arXiv:hep-th/0209114.

17. <span id="ref-Kunz"></span>

    J. Kunz and F. Navarro-Lérida, "$D=5$ Einstein--Maxwell--Chern--Simons black holes," *Phys. Rev. Lett.* **96** (2006) 081101, arXiv:hep-th/0510250.

18. <span id="ref-Li2026"></span>

    Q. Li, Y. Liu and W. Zhu, "Entanglement islands of 2D charged scalar-hairy black holes on the brane," 2026.
