---
title: 同调、上同调与 de Rham 上同调
date: '2026-11-16T14:25:00+08:00'
lastmod: '2026-11-16T14:25:00+08:00'
summary: 从边界算子、链复形与微分形式出发，理解同调、上同调及 RT/HRT 的相对同调约束。
tags:
- 同调
- 上同调
- 全息纠缠熵
math: true
showTableOfContents: true
draft: false
downloads:
  markdown: true
  pdf: true
  resources:
  - boundary-cycle.png
  - punctured-plane.png
  - hrt-relative-homology.png
---

*从闭合曲线到 HRT 同调约束的物理学入门笔记*

围绕二维膜黑洞纠缠岛研究的讨论整理；原稿日期：2026年7月11日。

## 摘要

本文面向物理系本科生，从"一个闭合回路能否在所处空间中被填起来"这一几何问题出发，依次介绍边界算子、链复形、同调群、上同调群、微分形式和 de Rham 上同调，并用广义 Stokes 定理解释同调与上同调之间的积分配对。文末将这些概念应用到全息纠缠熵：解释 RT/HRT 面的同调约束、Planck 膜存在时的相对同调，以及岛区域为何成为断开 HRT 面所围 bulk 区域的一部分。正文尽量减少抽象代数预设，并为关键公式配备几何解释。

## 1 一幅总图景

整份笔记可以压缩成一句话：

> **直观理解**
>
> 同调研究"哪些闭合几何对象无法在空间内部填起来"；上同调研究"有哪些测量能够探测这些不可填充对象"；de Rham 上同调用微分形式及其积分实现这种测量。

三组最重要的平行关系是

$$
\boxed{
\begin{array}{ccc}
\text{几何链} & \longleftrightarrow & \text{微分形式}\\
\partial & \longleftrightarrow & \mathrm d \\
\partial^2=0 & \longleftrightarrow & \mathrm d ^2=0\\
\partial C=0 & \longleftrightarrow & \mathrm d \omega=0\\
C=\partial D & \longleftrightarrow & \omega=\mathrm d \eta
\end{array}}
\tag{1}
$$

其中 $\partial$ 是几何对象的边界算子，$\mathrm d$ 是微分形式的外微分。

## 2 从边界算子开始

### 2.1 有向几何对象的边界

设 $C$ 是一个有方向的几何对象，用 $\partial C$ 表示它的边界。最熟悉的例子是

$$
\begin{align}
\partial(\text{线段})&=\text{终点}-\text{起点}, \tag{2}\\
\partial(\text{圆盘})&=\text{圆周}, \tag{3}\\
\partial(\text{实心球})&=\text{球面}. \tag{4}
\end{align}
$$

若有向线段从 $v_0$ 指向 $v_1$，记为 $[v_0v_1]$，则

$$
\partial[v_0v_1]=[v_1]-[v_0].
\tag{5}
$$

减号编码的是取向，而不是点集相减。

对于定向三角形 $[v_0v_1v_2]$，

$$
\partial[v_0v_1v_2]
=[v_1v_2]-[v_0v_2]+[v_0v_1].
\tag{6}
$$

再作用一次边界算子，每个顶点以相反符号出现两次并抵消，因此

$$
\boxed{\partial^2=0.}
\tag{7}
$$

> **直观理解**
>
> "边界的边界为零"是同调理论的起点。圆盘的边界是圆周，而圆周没有端点；实心球的边界是球面，而球面自身没有边界。

### 2.2 闭合不等于非平凡

图 [1](#fig-boundary-cycle) 中，圆周 $C$ 没有端点，所以 $\partial C=0$；但它又是圆盘 $D$ 的边界，即 $C=\partial D$。因此这个闭合回路在同调中是平凡的。

<div id="fig-boundary-cycle" style="scroll-margin-top: 110px;"></div>

![图 1](boundary-cycle.png)

**图 1**：可填充的闭链：$C$ 虽然闭合，但它是圆盘 $D$ 的边界，因此代表零同调类。

## 3 链、闭链、边界链与同调群

### 3.1 最低限度的抽象代数

同调计算中需要把几何对象相加，例如 $C_1-C_2$。因此我们使用阿贝尔群：一组可以相加、存在零元和负元，并满足交换律的对象。最常见的例子是 $\mathbb Z$、$\mathbb Z ^n$ 和 $\mathbb R ^n$。

把所有 $k$ 维基本几何块的整数形式线性组合记为 $C_k$，称作 $k$-链群：

- $C_0$ 由点生成；

- $C_1$ 由有向边或曲线生成；

- $C_2$ 由有向三角形或曲面生成；

- $C_3$ 由三维胞腔生成。

边界算子降低维数：

$$
\partial_k:C_k\longrightarrow C_{k-1}.
\tag{8}
$$

这些群和映射组成链复形

$$
\cdots\xrightarrow{\partial_{k+1}}C_k
\xrightarrow{\partial_k}C_{k-1}
\xrightarrow{\partial_{k-1}}\cdots,
\qquad \partial_k\partial_{k+1}=0.
\tag{9}
$$

### 3.2 闭链与边界链

若 $C\in C_k$ 满足

$$
\partial C=0,
\tag{10}
$$

则称 $C$ 为 $k$-闭链。所有闭链构成

$$
Z_k=\ker\partial_k.
\tag{11}
$$

若存在 $D\in C_{k+1}$ 使得

$$
C=\partial D,
\tag{12}
$$

则称 $C$ 为边界链。所有边界链构成

$$
B_k=\operatorname{im}\partial_{k+1}.
\tag{13}
$$

由 $\partial^2=0$ 立即得到

$$
B_k\subseteq Z_k.
\tag{14}
$$

也就是说，边界一定闭合，但闭合对象不一定是边界。

### 3.3 同调群的定义

第 $k$ 阶同调群定义为

$$
\boxed{H_k=\frac{Z_k}{B_k}
=\frac{\ker\partial_k}{\operatorname{im}\partial_{k+1}}.}
\tag{15}
$$

商群 $Z_k/B_k$ 的含义是：如果两个闭链只相差一个边界，就将它们视为等价：

$$
C_1\sim C_2
\quad\Longleftrightarrow\quad
C_1-C_2=\partial D.
\tag{16}
$$

闭链 $C$ 所在的等价类记为 $[C]$。若 $C=\partial D$，则 $[C]=0$。

> **直观理解**
>
> 同调忽略闭链的精确形状，只记录它绕过了哪些洞。如果 $C_1$ 可以扫过一条带状区域变成 $C_2$，并且过程中不穿过洞，那么两者属于同一个同调类。

### 3.4 穿孔平面

考虑

$$
M=\mathbb R ^2\setminus\{0\}.
\tag{17}
$$

绕原点一周的圆 $C$ 满足 $\partial C=0$，但不存在完全位于 $M$ 内的圆盘 $D$ 使 $C=\partial D$，因为任何填充都必须经过已删除的原点。因此

$$
[C]\neq0\in H_1(M).
\tag{18}
$$
<div id="fig-punctured-plane" style="scroll-margin-top: 110px;"></div>

![图 2](punctured-plane.png)

**图 2**：穿孔平面中的非平凡闭链，以及用闭1-形式的周期积分探测该同调类。

## 4 不同阶同调的直观含义

粗略地说，$H_k$ 探测 $k$ 维不可填充对象：

| 同调群 | 主要探测的结构 |
|:------:|:---------------|
| $H_0$  | 连通分支       |
| $H_1$  | 独立环路或隧道 |
| $H_2$  | 闭合壳层或空腔 |
| $H_3$  | 更高维空腔     |

若使用实数系数并有

$$
H_k(M;\mathbb R )\cong\mathbb R ^{b_k},
\tag{19}
$$

则 $b_k$ 称为第 $k$ 个 Betti 数，可粗略看作独立 $k$ 维洞的数目。

几个常见空间的同调为

$$
\begin{align}
H_0(S^1)&\cong\mathbb Z ,& H_1(S^1)&\cong\mathbb Z , \tag{20}\\
H_0(S^2)&\cong\mathbb Z ,& H_1(S^2)&=0,& H_2(S^2)&\cong\mathbb Z , \tag{21}\\
H_0(T^2)&\cong\mathbb Z ,& H_1(T^2)&\cong\mathbb Z ^2,& H_2(T^2)&\cong\mathbb Z . \tag{22}
\end{align}
$$

环面 $T^2$ 的两个独立1-循环分别沿"大圆方向"和"小圆方向"。

## 5 如何计算同调

### 5.1 空心与实心三角形

设三个顶点为 $v_0,v_1,v_2$，三条有向边为 $e_{01},e_{12},e_{20}$。边界为

$$
\begin{align}
\partial e_{01}&=v_1-v_0, \tag{23}\\
\partial e_{12}&=v_2-v_1, \tag{24}\\
\partial e_{20}&=v_0-v_2. \tag{25}
\end{align}
$$

闭合回路

$$
C=e_{01}+e_{12}+e_{20}
\tag{26}
$$

满足 $\partial C=0$。

若三角形内部为空，没有二维面 $f$，则 $C$ 不是边界，产生 $H_1\cong\mathbb Z$。若加入二维面

$$
f=[v_0v_1v_2],
\tag{27}
$$

则

$$
\partial f=e_{01}+e_{12}+e_{20}=C,
\tag{28}
$$

原先的一维洞被填掉，因而 $H_1=0$。

### 5.2 边界矩阵

实际计算时，将 $\partial_k$ 写成矩阵 $D_k$，然后求

$$
\ker D_k,
\qquad
\operatorname{im}D_{k+1}.
\tag{29}
$$

若系数取在域 $\mathbb R$ 或 $\mathbb Q$ 上，则

$$
\boxed{b_k
=\dim C_k-\operatorname{rank}D_k-\operatorname{rank}D_{k+1}.}
\tag{30}
$$

若使用整数系数，还可能出现 $\mathbb Z _n$ 型挠率，需要用 Smith 标准形计算。物理中若只关心连续零模，实系数通常足够；若关心离散电荷或量子化信息，则整数系数更重要。

## 6 从同调到上同调

### 6.1 上链是链的测量工具

同调使用几何链 $C_k$。上同调使用对链赋值的函数，称为上链：

$$
C^k=\operatorname{Hom}(C_k,G).
\tag{31}
$$

一个 $k$-上链 $\varphi$ 接收 $k$-链并输出一个数：

$$
\varphi(C)\in G.
\tag{32}
$$

因此可以把同调链看作被测对象，把上链看作测量探针。

上边界算子定义为

$$
(\delta\varphi)(C_{k+1})=\varphi(\partial C_{k+1}),
\tag{33}
$$

并满足 $\delta^2=0$。第 $k$ 阶上同调群为

$$
\boxed{H^k
=\frac{\ker\delta_k}{\operatorname{im}\delta_{k-1}}.}
\tag{34}
$$

> **直观理解**
>
> 同调问"空间中有哪些无法填充的闭合对象"；上同调问"有哪些全局测量能够识别这些对象"。穿孔平面上的测量应当对不绕洞的回路给出零，对绕洞一次给出固定非零值，对绕洞两次给出两倍结果。

## 7 微分形式与外微分

### 7.1 $k$-形式可以在 $k$ 维对象上积分

在光滑流形上，上链可以由微分形式实现。0-形式是普通函数 $f$；二维中的一般1-形式为

$$
\omega=P(x,y)\,\mathrm d  x+Q(x,y)\,\mathrm d  y,
\tag{35}
$$

可以沿曲线 $C$ 积分。二维中的2-形式为

$$
\Omega=F(x,y)\,\mathrm d  x\wedge\mathrm d  y,
\tag{36}
$$

可以在二维区域上积分。一般地，$k$-形式自然地在 $k$ 维定向链上积分。

### 7.2 外微分

外微分将 $k$-形式变为 $k+1$-形式：

$$
\mathrm d :\Omega^k(M)\longrightarrow\Omega^{k+1}(M).
\tag{37}
$$

对函数，

$$
\mathrm d  f=\frac{\partial f}{\partial x}\mathrm d  x
+\frac{\partial f}{\partial y}\mathrm d  y.
\tag{38}
$$

对二维1-形式，

$$
\mathrm d \omega
=\left(\frac{\partial Q}{\partial x}
-\frac{\partial P}{\partial y}\right)
\mathrm d  x\wedge\mathrm d  y.
\tag{39}
$$

外微分统一了梯度、旋度和散度，并满足

$$
\boxed{\mathrm d ^2=0.}
\tag{40}
$$

## 8 闭形式、恰当形式与 de Rham 上同调

若 $\mathrm d \omega=0$，则称 $\omega$ 为闭形式。若存在 $\eta$ 使

$$
\omega=\mathrm d \eta,
\tag{41}
$$

则称 $\omega$ 为恰当形式或恰形式。由于 $\mathrm d ^2=0$，

$$
\text{恰当}\quad\Longrightarrow\quad\text{闭合}.
\tag{42}
$$

但反过来只在局部成立，不一定全局成立。

第 $k$ 阶 de Rham 上同调定义为

$$
\boxed{
H_{\mathrm{dR}}^k(M)
=\frac{\ker(\mathrm d :\Omega^k\to\Omega^{k+1})}
{\operatorname{im}(\mathrm d :\Omega^{k-1}\to\Omega^k)}
=\frac{\text{闭 }k\text{-形式}}{\text{恰当 }k\text{-形式}}.}
\tag{43}
$$

若两个闭形式只相差一个恰当形式，

$$
\omega_1-\omega_2=\mathrm d \eta,
\tag{44}
$$

则它们属于同一 de Rham 上同调类。

### 8.1 穿孔平面上的闭但不恰当形式

在 $M=\mathbb R ^2\setminus\{0\}$ 上考虑

$$
\boxed{
\omega=\frac{-y\,\mathrm d  x+x\,\mathrm d  y}{x^2+y^2}.}
\tag{45}
$$

在原点之外有 $\mathrm d \omega=0$，所以它是闭形式。在极坐标中它局部等于 $\mathrm d \theta$。但沿单位圆积分得到

$$
\oint_C\omega=\int_0^{2\pi}\mathrm d \theta=2\pi.
\tag{46}
$$

若存在全局单值函数 $f$ 使 $\omega=\mathrm d  f$，则任意闭合回路上都应有 $\oint_C\mathrm d  f=0$，与上式矛盾。因此 $\omega$ 闭但不全局恰当，并代表

$$
H_{\mathrm{dR}}^1(\mathbb R ^2\setminus\{0\})\cong\mathbb R 
\tag{47}
$$

中的非零元素。

### 8.2 Poincaré 引理

在开球、星形区域等可缩的局部区域内，Poincaré 引理给出

$$
\mathrm d \omega=0\quad\Longrightarrow\quad\omega=\mathrm d \eta.
\tag{48}
$$

因此 de Rham 上同调反映的是全局拓扑障碍，而不是局部微分障碍：

$$
\boxed{\text{局部：闭形式通常恰当；全局：洞可能阻止恰当性。}}
\tag{49}
$$

## 9 Stokes 定理：同调与上同调的桥梁

广义 Stokes 定理为

$$
\boxed{\int_{\partial C}\omega=\int_C\mathrm d \omega.}
\tag{50}
$$

它统一了微积分基本定理、Green 定理、旋度形式的 Stokes 定理和 Gauss 散度定理。

若 $C=\partial D$ 且 $\mathrm d \omega=0$，则

$$
\int_C\omega=\int_{\partial D}\omega
=\int_D\mathrm d \omega=0.
\tag{51}
$$

若 $\omega=\mathrm d \eta$ 且 $\partial C=0$，则

$$
\int_C\omega=\int_C\mathrm d \eta
=\int_{\partial C}\eta=0.
\tag{52}
$$

因此积分只依赖于同调类 $[C]$ 和上同调类 $[\omega]$：

$$
H_{\mathrm{dR}}^k(M)\times H_k(M;\mathbb R )
\longrightarrow\mathbb R ,
\qquad
([\omega],[C])\longmapsto\int_C\omega.
\tag{53}
$$

de Rham 定理进一步说明

$$
\boxed{H_{\mathrm{dR}}^k(M)\cong H^k(M;\mathbb R ).}
\tag{54}
$$

> **物理联系**
>
> 在规范场论中，闭合回路上的 Wilson 环、闭曲面上的电磁通量以及背景规范场的拓扑扇区，都体现了"用微分形式的积分探测同调循环"这一思想。

## 10 "闭"字的四种不同含义

> **容易混淆之处**
>
> 闭链、闭形式、无边界流形和拓扑闭集是不同概念，不能仅因都使用"闭"字就混为一谈。

| **说法**       | 数学条件                 |
|:---------------|:-------------------------|
| **闭链**       | $\partial C=0$           |
| **无边界流形** | $\partial M=\varnothing$ |
| **闭形式**     | $\mathrm d \omega=0$     |
| **拓扑闭集**   | 集合包含自己的全部极限点 |

"一个闭合曲面是否是某区域的边界"还取决于环境空间。例如圆周作为 $\mathbb R ^2$ 中的曲线是圆盘的边界，但作为空间 $S^1$ 自身中的1-链，它不是 $S^1$ 内任何二维链的边界，因为 $S^1$ 本身没有二维区域。类似地，$S^2$ 在 $\mathbb R ^3$ 中是实心球的边界，但在 $S^2$ 自身内部不是任何三维链的边界。

## 11 RT/HRT 中的同调约束

### 11.1 普通 AdS/CFT 中的约束

在静态 RT 公式中，极值面 $\gamma_A$ 不仅要满足

$$
\partial\gamma_A=\partial A,
\tag{55}
$$

还必须与边界区域 $A$ 同调，记作

$$
\gamma_A\sim A.
\tag{56}
$$

其含义是：存在 bulk 中的高一维区域 $r_A$，使得

$$
\boxed{\partial r_A=A-\gamma_A.}
\tag{57}
$$

若忽略取向符号，可简写为

$$
\partial r_A=A\cup\gamma_A.
\tag{58}
$$

> **直观理解**
>
> HRT 面不能只与 $A$ 拥有相同端点；它还必须与 $A$ 一起真正围成一个 bulk 区域。即使某条候选极值面面积更小，如果它不能满足该条件，也不能用于计算 $S(A)$。

区域 $r_A$ 的因果发展给出纠缠楔。因此，同调约束不仅是形式上的拓扑要求，也决定边界子系统能够重构哪部分 bulk 信息。

### 11.2 Planck 膜、相对同调与岛

在本文所研究的双重全息模型中，断开 HRT 面 $\gamma_R$ 可以终止在 Planck 膜 $\mathcal B$ 上。此时辐射区域 $R$ 与 $\gamma_R$ 不能单独构成某个 bulk 区域的完整边界，还需要加入膜上的区域 $\mathcal I$：

$$
\boxed{\partial r_R=R\cup\gamma_R\cup\mathcal I ,}
\tag{59}
$$

其中取向符号从略。膜上区域 $\mathcal I$ 就是岛，而

$$
\partial\mathcal I =\gamma_R\cap\mathcal B 
\tag{60}
$$

给出岛端点或量子极值面。

<div id="fig-hrt-homology" style="scroll-margin-top: 110px;"></div>

![图 3](hrt-relative-homology.png)

**图 3**：带 Planck 膜时的相对同调约束。辐射区域、断开 HRT 面和膜上岛区域共同构成 bulk 区域 $r_R$ 的完整边界。

更严格地说，这里使用相对同调 $H_k(M,\mathcal B )$。相对同调允许链的部分边界落在指定子空间 $\mathcal B$ 上。在当前问题中，可以把它理解为：Planck 膜是极值面被允许终止的特殊边界，而膜上的岛区域补齐了同调所需的边界片段。

### 11.3 同调约束、极值方程和正交条件

这三个条件回答不同问题：

| **条件**     | 回答的问题                                       |
|:-------------|:-------------------------------------------------|
| **同调约束** | 候选面能否与边界区域共同围成合法 bulk 区域？     |
| **极值方程** | 曲线或曲面的内部是否使面积泛函取驻值？           |
| **正交条件** | 当端点可沿膜滑动时，端点变分是否也使面积取驻值？ |

对于论文第二章的断开面，正交条件为

$$
\frac{1}{f(z_p)}+x'(z_p)X'(z_p)=0.
\tag{61}
$$

它是局部变分边界条件，不是由同调约束或柯西曲面概念推出的。

## 12 常用计算路线

### 12.1 计算同调

1.  将空间三角剖分，或选择 CW 胞腔分解；

2.  列出各维链群 $C_k$；

3.  根据取向写出边界矩阵 $D_k$；

4.  计算 $\ker D_k$ 与 $\operatorname{im}D_{k+1}$；

5.  取商得到 $H_k$。域系数下可用高斯消元，整数系数下可用 Smith 标准形。

### 12.2 计算 de Rham 上同调

1.  写出一般 $k$-形式 $\omega$；

2.  求解闭合条件 $\mathrm d \omega=0$；

3.  模掉所有恰当形式 $\omega=\mathrm d \eta$；

4.  通过非平凡循环上的周期积分 $\int_C\omega$ 检验剩余形式；

5.  或先计算实系数同调，再利用 de Rham 定理判断维数。

在紧致定向黎曼流形上，还可使用 Hodge 定理：每个 de Rham 上同调类都有唯一调和代表，满足

$$
\Delta\omega=0,
\qquad
\Delta=\mathrm d \mathrm d ^\dagger+\mathrm d ^\dagger\mathrm d .
\tag{62}
$$

这使拓扑零模问题可以转化为偏微分方程问题。

## 13 总结

最值得保留的记忆框架是

$$
\boxed{
H_k=\frac{\text{闭链}}{\text{边界链}},
\qquad
H_{\mathrm{dR}}^k
=\frac{\text{闭形式}}{\text{恰当形式}}.}
\tag{63}
$$

同调类 $[C]$ 表示不可在当前空间中填充的闭合几何对象；de Rham 上同调类 $[\omega]$ 表示能够通过周期积分探测这些对象的闭形式。两者由

$$
\int_{\partial C}\omega=\int_C\mathrm d \omega
\tag{64}
$$

联系起来。

对 HRT/岛问题，最重要的公式是

$$
\boxed{
\gamma_R\sim R
\quad\Longleftrightarrow\quad
\exists\,r_R:\ \partial r_R=R\cup\gamma_R
}
\tag{65}
$$

以及有膜时的相对同调形式

$$
\boxed{
\exists\,r_R:\ \partial r_R=R\cup\gamma_R\cup\mathcal I .
}
\tag{66}
$$

后一个式子给出了岛的直接几何解释：岛是为使辐射区域与断开 HRT 面共同满足同调约束而必须补入的膜上区域。

## 参考资料

1.  Q. Li, Y. Liu and W. Zhu, *Entanglement islands of 2D charged scalar-hairy black holes on the brane*, 2026，重点参见第2章。

2.  H.-S. Chen et al., *Quantum Extremal Islands Made Easy, Part I: Entanglement on the Brane*, 2020。

3.  H.-S. Chen et al., *Quantum Extremal Islands Made Easy, Part II: Black Holes on the Brane*, 2020。

4.  关于代数拓扑的一般背景，可进一步查阅链复形、奇异同调、相对同调、de Rham 定理和 Hodge 定理的标准教材章节。
