---
title: '证明：在一维无限深方势阱外波函数仅存在平凡解'
date: '2026-11-12T11:00:00+08:00'
lastmod: '2026-11-12T11:00:00+08:00'
summary: '从有限深方势阱出发讨论束缚态波函数与无限深势阱极限'
tags: ["量子力学","薛定谔方程","势阱"]
mathPackages: [physics]
math: true
showTableOfContents: true
draft: false
downloads:
  markdown: true
  resources: ["square-well.png"]
---

## 对称性分析

通常情形下我们对一维无限深方势阱函数选择为：

$$
V(x)=\begin{cases}
&0 &\quad 0\le x \le L,\\
&\infty &\quad \text{otherwise}.
\end{cases}
$$

该函数显然存在一个对称轴，为标准化我们重新选取坐标系使得：

$$
s.t.\begin{cases}
2a&=&L,\\
x&=&x-a.
\end{cases}
$$

得到标准化的势函数

$$
V(x)=\begin{cases}
&0 &\quad \abs{x} \le a,\\
&\infty &\quad \abs{x}>a.
\end{cases}
$$

显然，标准化势函数为偶函数。我们可以考虑这样的一个极限过程：对于有限高的势阱$V'(x)$满足

$$
V'(x)=\begin{cases}
&0 &\quad \abs{x} \le a,\\
&V_0 &\quad \abs{x}>a.
\end{cases}\quad (V_0\in\mathbb{R}_+)
$$

显然$V(x)=\lim_{V_0\to\infty}V'(x)$。为方便起见，我们接下来在不会引起误解的情况下将$V'(x)$称作$V(x)$。考虑到有限高的边界并不适合处理，我们仍然重新选择坐标系使得$V\to V-V_0$，从而有

$$
V(x)=\begin{cases}
&-V_0 &\quad \abs{x} \le a,\\
&0 &\quad \abs{x}>a.
\end{cases}\quad (V_0=\mathrm{const})
$$

此时我们得到了一个标准的有限深方势阱函数$V(x)$。

已知定态波函数$\psi(x)$满足定态Schrodinger方程：

$$
-\frac{\hbar^2}{2m}\frac{\mathrm{d}^2 \psi(x)}{\dd x^2}+V(x)\psi(x)=E\psi(x)
$$

对上述SODE做变换$x\to-x$可以得到：

$$
-\frac{\hbar^2}{2m}\frac{\mathrm{d}^2 \psi(-x)}{\dd x^2}+V(-x)\psi(-x)=E\psi(-x)
$$

又$V(x)=V(-x)$，故可知定态波函数满足$\psi(x)=\psi(-x)$，即定态波函数为偶函数，故我们可以仅考虑$x>0$的部分而不失一般性。

<img src="square-well.png" alt="一维无限深势阱" style="zoom: 50%;" />

## 求解定态Schrodinger方程

### 有限深方势阱内

对于$0<x<a$的部分约束态波函数，满足能量条件为$-V_0<E<0$，则定态Schrodinger方程化为

$$
\frac{\mathrm{d}^2 \psi}{\dd x^2}=-\frac{2m}{\hbar^2}(E+V_0)\psi
$$

通解为

$$
\psi=A\sin(kx)+B\cos(kx),\quad \qty(k^2=\frac{2m(E+V_0)}{\hbar^2})
$$

由对称性分析可知，$A=0$.

### 有限深方势阱外

对于$x>a$的部分约束态波函数，满足能量条件为$E<0$，则定态Schrodinger方程化为

$$
\frac{\mathrm{d}^2 \psi}{\dd x^2}=-\frac{2mE}{\hbar^2}\psi
$$

通解为

$$
\psi=C\exp(\kappa x)+D\exp(-\kappa x),\quad \qty(\kappa^2=-\frac{2mE}{\hbar^2})
$$

由于波函数满足有界条件$\lim_{x\to\infty}\psi=0$，故$C=0$。

从而我们有

$$
\psi(x)=\begin{cases}
B\cos(kx) \quad&0\le x\le a,\\
D\exp(-\kappa x)\quad& x>a,\\
\psi(-x)\quad & x<0.
\end{cases}
$$

考虑波函数的边界条件

$$
\begin{cases}
\psi(a_-)=\psi(a_+),\\
\eval{\dfrac{\dd \psi}{\dd x}}_{x=a_-}=\eval{\dfrac{\dd \psi}{\dd x}}_{x=a_+}.
\end{cases}
$$

代入通解可得

$$
\begin{cases}
B\cos(ka)=D\exp(-\kappa a),\\
-kB\sin(ka)=-\kappa D\exp(-\kappa a).
\end{cases}
$$

下式除以上式可得

$$
\kappa = k\tan(ka)
$$

到此我们基本可以看出该方程为超越方程，且由于$k$与$\kappa$与能量条件相关联，我们可以敏锐察觉到我们已经得到了束缚态下各基态应当满足的方程。为了更加明显地体现出能量的关系，我们进行如下变量代换：

$$
\begin{cases}
ka=l,\\
\dfrac{2mV_0}{\hbar^2}=(al_0)^2
\end{cases}
$$

由$k$与$\kappa$的定义，我们知道二者满足如下关系：

$$
k^2+\kappa^2=\frac{2mV_0}{\hbar^2}
$$

故可将$\kappa$与$k$的关系用关于$l$的方程表述：

$$
\pm\sqrt{\frac{l_0^2}{l^2}-1}=\tan l
$$

为讨论方便，我们不妨先选取大于0的部分，则

$$
\sqrt{\frac{l_0^2}{l^2}-1}=\tan l
$$

## 考虑极限情形下是否能退化为一维无限深方势阱的情况

考虑$V_0\to\infty$，则$l_0^2\to\infty$，$\sqrt{l_0^2/l^2 - 1}\to \infty$，故能满足方程的$l$应当满足$l\to n\pi/2$，且$n$为奇数。此时，将$l$写为$E$和$V_0$的函数，展开可得

$$
E_n+V_0\approx \frac{n^2\pi^2\hbar^2}{2m(2a)^2},\quad \qty(n=1,3,5,\cdots)
$$

可见，此时上式右侧正是一维无限深方势阱的能量条件数量的一半，当考虑所有的$n$时（即考虑“$\pm$”），右侧就变成了一维无限深方势阱的能量条件，可见从能量条件上来看满足主动退化。

再考虑当$V_0\to\infty$时，势阱外的波函数$\psi$的变化。由于$\kappa$满足

$$
\kappa^2=\frac{l_0^2}{a^2}-\frac{l^2}{a^2}=\frac{1}{a^2}\qty(l_0^2-l^2)
$$

由于此时$l_0^2\to\infty$，$\kappa\to\infty$，$\psi=D\exp(-\kappa x)\to 0$，所以有一维无限深方势阱外波函数仅存在平凡解0。

最后考虑势阱内的情形，此时$l\to n\pi/2$，故$k\to n\pi/2a$，也与一维无限深方势阱内波函数的形式符合。

综上，我们从一维有限深方势阱的情况出发，证明了一维无限深势阱外波函数仅存在平凡解，且一维有限深方势阱的波函数能在极限情形下良好地退化为一维无限深方势阱的波函数。
