---
title: "Randall–Sundrum 与相关理论：从五维几何到 AdS/CFT"
date: "2026-11-12T11:00:00+08:00"
lastmod: "2026-11-12T11:00:00+08:00"
summary: "围绕五维几何理解 Randall–Sundrum 模型，并梳理 KK reduction、EMD、Gauss–Bonnet gravity 与 AdS/CFT 的关系"
tags: [AdS-CFT, braneworld, Kaluza-Klein, Einstein-Maxwell-dilaton, Gauss-Bonnet]
math: true
showTableOfContents: true
draft: false
downloads:
  markdown: true
sourceMetadata:
  type: concept_note
  created: 2026-09-30
  updated: 2026-09-30
  verification_status: verified
  evidence_type: [source_claim, analytic_derivation]
  aliases: [Randall-Sundrum model, RS and KK compactification]
---

学习目标：理解 Randall–Sundrum model（RS model）如何利用五维几何产生四维引力与能标层级；区分它与 Kaluza–Klein reduction、Einstein–Maxwell–dilaton theory、Gauss–Bonnet gravity 以及两个 AdS product compactifications 的关系；建立基本 holographic dictionary。本文聚焦概念与可复用公式，不预设某个具体 black-hole solution 已经存在或稳定。

## 1. 一句话定义与阅读范围

**RS model 是带有 brane boundary conditions 的五维 warped geometry 模型；其主要机制是 geometric redshift 与 graviton localization。**

要比较几个理论名称，先问三个不同问题：

1. <strong>Action：</strong>理论中有哪些场，相互作用是什么？
2. <strong>Background：</strong>选取什么 metric、flux 和 scalar profile？
3. <strong>Reduction / boundary conditions：</strong>如何得到低维物理，保留哪些 modes，哪里有 brane 或 conformal boundary？

Kaluza–Klein（KK）是组织高维 modes 和降维的方法；Einstein–Maxwell–dilaton（EMD）与 Einstein–Gauss–Bonnet（EGB）是动力学理论；RS 与 $AdS_3\times S^2$、$AdS_4\times S^1$ 则进一步指定几何或边界方案。这些名称不处于同一分类层级。

<strong>适用前提：</strong>主要使用 classical effective field theory 与 linear perturbation 图像。标为 source_claim 的 duality、完整 reduction 和 phenomenology 来自文献；本文短推导只覆盖写出的公式与假设，不能代替稳定性分析或完整高维嵌入。

## 2. 知识网络：方法、理论与背景

| 名称 | 定义层面与它回答的问题 |
|---|---|
| Five-dimensional Einstein gravity | 五维 metric 的动力学；是否加 cosmological constant、matter 或 boundary action 必须另说。 |
| KK reduction | 把高维场展开为内部空间 eigenmodes，识别低维 metric、vectors、scalars 与 massive tower。 |
| EMD theory | 指定 Einstein term、Maxwell term、dilaton kinetic term、coupling function 和可能的 scalar potential。 |
| EGB gravity | 在 Einstein action 中加入 Gauss–Bonnet curvature-squared combination。 |
| RS1 / RS2 | 选择 $AdS_5$ warped background、brane tensions 与 orbifold / boundary conditions。 |
| $AdS_3\times S^2$ | 五维 product background；沿 $S^2$ 降维后 external spacetime 为三维。 |
| $AdS_4\times S^1$ | 五维 product background；沿 $S^1$ 降维后 external spacetime 为四维。 |
| AdS/CFT correspondence | 高维 gravity 与低维 quantum field theory 的 holographic relation，不等于 KK reduction。 |

<strong>个人理解：</strong>同一 action 可以拥有不同 backgrounds；同一形式的 background 也可能被不同 matter content 支撑。不能从“总维数都是五维”推出模型等价。

## 3. 符号、单位与约定

采用 natural units $c=\hbar=1$。除角坐标外，坐标具有 length 单位；metric signature 为 mostly plus：$(-,+,+,+,+)$。曲率约定满足 $AdS_D$ 中 $R_{AB}=-(D-1)g_{AB}/\ell^2$，并取
$[\nabla_C,\nabla_D]v^A=R^A{}_{BCD}v^B$。
主文使用 Einstein frame。Branes 不与 AdS conformal boundary 混同。

| 符号 | 定义、单位与使用范围 |
|---|---|
| $A,B=0,\ldots,4$ | 五维 spacetime indices；$\mu,\nu=0,\ldots,3$ 为四维 indices。 |
| $d$ | Conformal boundary spacetime dimension；$AdS_{d+1}$ 的 bulk dimension 为 $d+1$。 |
| $G_D,M_D$ | $[G_D]=\mathrm{length}^{D-2}$；reduced Planck scale 满足 $M_D^{D-2}=(8\pi G_D)^{-1}$。 |
| $\Lambda_5$ | Cosmological constant，$[\Lambda_5]=\mathrm{length}^{-2}$；action 写成 $R-2\Lambda_5$。 |
| $k,\ell$ | RS curvature scale 与 radius：$k=1/\ell$，$[k]=\mathrm{length}^{-1}$。 |
| $y,L$ | Proper-distance coordinate 与两膜间距，单位为 length；$L=\pi r_c$。 |
| $W(y)$ | Warp exponent，$W=-k\lvert y\rvert$；避免与 gauge potential $A_\mu$ 混淆。 |
| $\lambda_i$ | Brane tension，$[\lambda_i]=\mathrm{length}^{-4}$。 |
| $\phi,A_\mu,F=dA$ | Dilaton、gauge potential 与 field strength；统一引力前因子约定下，前两者无量纲，$[F]=\mathrm{length}^{-1}$。 |
| $a,V(\phi)$ | Dilaton coupling（无量纲）与 scalar potential（$\mathrm{length}^{-2}$）。 |
| $\alpha,\mathcal G$ | GB coupling：$[\alpha]=\mathrm{length}^2$；GB density：$[\mathcal G]=\mathrm{length}^{-4}$。 |
| $\ell_3,r_2,\ell_4,R_c$ | Product backgrounds 的 AdS radii 与 internal radii，单位均为 length。 |
| $q$ | Sphere magnetic-flux parameter；第 10 节归一化下 $[q]=\mathrm{length}$。 |
| $m,\Delta,\mathcal O,J$ | Bulk scalar mass：$[m]=\mathrm{length}^{-1}$；operator dimension $\Delta$ 无量纲；QFT 中 $[\mathcal O]=\mathrm{length}^{-\Delta}$、$[J]=\mathrm{length}^{\Delta-d}$。 |

有的文献写 $2M^3R-\Lambda_{\rm density}$，或将 scalar kinetic term 写成 $-2(\partial\varphi)^2$。比较系数前必须映射 action normalization，不能直接抄用 $\Lambda$ 或 $a$ 的数值。

## 4. AdS geometry：四维切片可以平直

source_claim：Poincaré patch 中

$$
ds^2_{AdS_{d+1}}=\frac{\ell^2}{z^2}
\left(dz^2+\eta_{\mu\nu}dx^\mu dx^\nu\right),\qquad z>0.
$$

Conformal boundary 位于 $z\to0$；除去整体 conformal factor 后得到 boundary metric。[Witten，boundary geometry 与 field asymptotics](https://arxiv.org/abs/hep-th/9802150)

analytic_derivation：令 $z=\ell e^{y/\ell}$，则 $dz=(z/\ell)dy$，所以

$$
ds^2=e^{-2y/\ell}\eta_{\mu\nu}dx^\mu dx^\nu+dy^2.
$$

固定 $y$ 的切片可以是 Minkowski spacetime，而整个五维 bulk 仍是负曲率 AdS。RS 的 $\lvert y\rvert$ 体现反射与膜的拼接；brane 处的导数跳跃由 junction conditions 控制。

<strong>物理图像：</strong>沿 $y$ 改变时，各切片上的时间、长度与能标相对于共同的四维归一化发生 redshift。平直切片并不意味着五维 curvature 为零。

## 5. RS1：geometric redshift 与 hierarchy

source_claim：采用本文归一化，原始 RS action 的结构为

$$
S=\frac{M_5^3}{2}\int d^5x\sqrt{-g}(R-2\Lambda_5)
-\sum_i\lambda_i\int_{\mathcal B_i}d^4x\sqrt{-h_i}
+S_{\rm matter}+S_{\rm boundary}.
$$

$h_i$ 是 induced metric，$S_{\rm boundary}$ 包含使 variational principle 良定义的 boundary terms。背景为

$$
ds^2=e^{-2k\lvert y\rvert}\eta_{\mu\nu}dx^\mu dx^\nu+dy^2.
$$

RS1 定义在 $S^1/\mathbb Z_2$ 上；基本区间为 $0\le y\le L$，两端为 ultraviolet（UV）brane 与 infrared（IR）brane。采用 $Z_2$ doubled-cover convention：

$$
\Lambda_5=-6k^2,\qquad
\lambda_{\rm UV}=+6M_5^3k,\qquad
\lambda_{\rm IR}=-6M_5^3k.
$$

这些系数对应平直 branes 与本文 Einstein action convention；法向和边界描述必须一致。[RS1，set-up 与 warped solution](https://arxiv.org/abs/hep-ph/9905221)

### 5.1 为什么质量只带一个 warp factor？

analytic_derivation：一个 scalar $H$ 位于 IR brane，原始质量为 $m_0$。由
$h_{\mu\nu}=e^{-2kL}\eta_{\mu\nu}$，
得到 $\sqrt{-h}=e^{-4kL}$、$h^{\mu\nu}=e^{2kL}\eta^{\mu\nu}$，因此

$$
S_H=-\frac12\int d^4x
\left[e^{-2kL}(\partial H)^2+e^{-4kL}m_0^2H^2\right].
$$

定义 canonical field $H_c=e^{-kL}H$，得到

$$
\boxed{m_{\rm 4D}=e^{-kL}m_0}.
$$

质量平方带 $e^{-2kL}$，质量本身带 $e^{-kL}$。

$m_{\rm 4D}$ 是四维 Einstein-frame normalization 下相对于引力能标的质量。IR observer 采用 proper units 可以把局部 metric 归一化；可观测内容是 mass ratios，而不是钟尺单位的改变。

例如 $kL=\ln(10^{15})\simeq34.54$，就有 $m_{\rm 4D}/m_0=10^{-15}$。这是指数层级，不要求额外维长度本身存在 $10^{15}$ 的层级。

### 5.2 Radion 与 stabilization

source_claim：$L$ 随四维位置变化会产生 radion（膜间距的动态自由度）。原始 RS1 不自动确定其稳定值。Goldberger–Wise mechanism 引入 bulk scalar 与 brane potentials，为 radion 生成有效势。[Goldberger–Wise，Modulus Stabilization with Bulk Fields](https://arxiv.org/abs/hep-ph/9907447)

Radion 与 KK radius modulus 的物理意义相似，但其 effective action 和 matter couplings 依赖 warp 与 branes，不能直接等同于任意 EMD dilaton。

## 6. RS2：非紧致额外维与 graviton localization

analytic_derivation：把 graviton zero mode 对应的四维 Einstein term 从五维 action 中提出：

$$
M_{\rm Pl}^2=M_5^3\int_{-L}^{L}dy\,e^{-2k\lvert y\rvert}
=\frac{M_5^3}{k}(1-e^{-2kL}).
$$

移走 IR brane、取 $L\to\infty$ 后，

$$
\boxed{M_{\rm Pl}^2=\frac{M_5^3}{k}<\infty}.
$$

这里使用 doubled cover；只在半区间积分时必须同步改变 bulk normalization，不能凭空丢掉因子 2。

source_claim：RS2 存在 normalizable massless graviton zero mode，并有无 mass gap 的 continuous massive KK spectrum。长距离 $r\gg\ell$ 的静态势为

$$
V_N(r)=-\frac{G_Nm_1m_2}{r}
\left[1+\mathcal O\!\left(\frac{\ell^2}{r^2}\right)\right].
$$

这里只写修正阶数；精确系数涉及 tensor structure 与 brane bending，不能从简单 scalar exchange 图像直接确定。[RS2，zero mode、KK spectrum 与 Newton potential](https://arxiv.org/abs/hep-th/9906064)

<strong>物理图像：</strong>无限 internal length 不意味着 graviton zero mode 不可归一化。决定低能引力的是带有 warp weight 的 norm，而不只是未加权体积。

## 7. KK reduction：RS 也有 KK modes，但不是经典圆模型

source_claim：经典 circle reduction 的 zero-mode ansatz 可写为

$$
ds_5^2=e^{\phi/\sqrt3}g_{\mu\nu}dx^\mu dx^\nu
+e^{-2\phi/\sqrt3}(dz+A_\mu dx^\mu)^2,
\qquad z\sim z+2\pi R_0.
$$

Retained fields 与 $z$ 无关，$g_{\mu\nu}$ 是四维 Einstein-frame metric。$R_0$ 是 coordinate radius，proper radius 为 $R_{\rm proper}=R_0e^{-\phi/\sqrt3}$。

若五维 action 是纯 Einstein term，保留上述 zero modes 后，

$$
\boxed{
S_4=\frac1{16\pi G_4}\int d^4x\sqrt{-g}
\left[R-\frac12(\partial\phi)^2-\frac14e^{-\sqrt3\phi}F^2\right]}.
$$

[KK–EMD，five-dimensional uplift 与特定 coupling](https://arxiv.org/abs/1909.00970)

### 7.1 Metric components 的低维解释

$g_{\mu\nu}$ 给出 metric，$g_{\mu z}$ 给出 graviphoton，$g_{zz}$ 给出 radius scalar。圆上坐标变换 $z\mapsto z-\chi(x)$ 导致 $A\mapsto A+d\chi$，所以 gauge symmetry 来自高维 diffeomorphism。

在未翘曲、$\phi=0$ 的平直圆上，

$$
\Phi(x,z)=\sum_{n\in\mathbb Z}\Phi_n(x)e^{inz/R_0},
\qquad m_n^2=m_0^2+\frac{n^2}{R_0^2}.
$$

Radius scalar 改变时，还要考虑 proper radius 与 Einstein-frame rescaling；上式不能无条件照搬到 RS。

analytic_derivation：令 metric exponents 为 $2a_K\phi$、$2b_K\phi$，
$a_K=1/(2\sqrt3)$、$b_K=-1/\sqrt3$。
Einstein term 前因子满足 $2a_K+b_K=0$；Maxwell exponent 为 $3b_K=-\sqrt3$。这些检查解释 Einstein frame 与 exponential coupling 的关系；完整 scalar kinetic coefficient 来自前述文献 reduction，不声称仅凭两个指数就已证明。

### 7.2 RS orbifold 改变 zero-mode content

RS 中仍可对 perturbations 进行 KK eigenmode expansion，但 profiles 要满足 warped wave equation 与 brane boundary conditions。RS1 的 massive spectrum 离散，RS2 的 massive spectrum 连续。

由 $y\mapsto-y$ 的 tensor transformation 可知，标准 RS1 中 $g_{\mu y}$ 为 odd，$g_{\mu\nu}$、$g_{yy}$ 为 even。因此经典 circle reduction 的 massless graviphoton zero mode 被 orbifold projection 去掉。**“有 KK tower”不等于“低能理论必然包含经典 KK 的 Maxwell field”。**

## 8. EMD：特定 KK 理论是其中一个成员

一般 $D$ 维 EMD action 为

$$
S_D=\frac1{16\pi G_D}\int d^Dx\sqrt{-g}
\left[R-\frac12(\partial\phi)^2-V(\phi)-\frac14f(\phi)F^2\right].
$$

常用 $f=e^{-a\phi}$。四维、canonical scalar normalization 下，第 7 节对应 $a=\sqrt3$、$V=0$。若文献写 $-2(\partial\varphi)^2-e^{-2a\varphi}\mathcal F^2$，则先作 $\phi=2\varphi$、$A=2\mathcal A$ 的 normalization mapping。

### 8.1 五维 cosmological constant 降维后是什么？

analytic_derivation：第 7 节 ansatz 中
$\sqrt{-g_5}=e^{\phi/\sqrt3}\sqrt{-g_4}$。
所以五维 $-2\Lambda_5$ 产生

$$
V_{\rm KK}(\phi)=2\Lambda_5e^{\phi/\sqrt3},
$$

不是与 radius scalar 无关的四维常数。“五维 Einstein–AdS circle reduction”与“给四维 EMD 随意加常数势”不同。

### 8.2 何时能得到 RS-like background？

analytic_derivation：当 $F=0$、$\phi=\phi_0$ 为常数时，

$$
V'(\phi_0)=0,\qquad R_{AB}=\frac{V(\phi_0)}3g_{AB}.
$$

若 $V(\phi_0)<0$，可有 $AdS_5$ bulk。平直 RS warp 要求 $V(\phi_0)=-12k^2$，还需 brane junction conditions。非平凡 $\phi(y)$ 或 $F$ 会 backreact，改变 warp 与 modes。

scalar equation 为

$$
\Box\phi-V'(\phi)-\frac14f'(\phi)F^2=0.
$$

因此 constant dilaton 与 nonzero flux 必须满足
$V'(\phi_0)+f'(\phi_0)F^2/4=0$。
不能把任意 pure magnetic solution 自动当作 exponential-coupling EMD 的 constant-dilaton solution。

## 9. Gauss–Bonnet：修改动力学，不是选择 compactification

source_claim：本文讨论 ordinary five-dimensional EGB theory：

$$
S_{\rm EGB}=\frac1{16\pi G_5}\int d^5x\sqrt{-g}
\left[R-2\Lambda_5+\alpha\mathcal G\right]
+S_{\rm brane}+S_{\rm boundary},
$$

$$
\mathcal G=R^2-4R_{AB}R^{AB}+R_{ABCD}R^{ABCD}.
$$

GB 是 Lovelock combination，在五维影响局域动力学而保持 metric field equations 为二阶。四维、constant coupling 的 GB bulk term 是 topological；scalar-dependent coupling 不是同一情形。[Gauss–Bonnet interaction in RS compactification](https://arxiv.org/abs/hep-th/0010193)

### 9.1 相同 AdS geometry，参数关系已经改变

analytic_derivation：五维 constant curvature $K=-k^2$ 有

$$
R=-20k^2,\quad R_{AB}R^{AB}=80k^4,\quad
R_{ABCD}R^{ABCD}=40k^4,\quad \mathcal G=120k^4.
$$

GB equation tensor 为

$$
H_{AB}=2\left(RR_{AB}-2R_{AC}R_B{}^C
-2R^{CD}R_{ACBD}+R_A{}^{CDE}R_{BCDE}\right)
-\frac12g_{AB}\mathcal G.
$$

各项在 constant curvature 上分别给出
$RR_{AB}=80k^4g_{AB}$、
$R_{AC}R_B{}^C=16k^4g_{AB}$、
$R^{CD}R_{ACBD}=16k^4g_{AB}$、
$R_A{}^{CDE}R_{BCDE}=8k^4g_{AB}$。
因此 $G_{AB}=6k^2g_{AB}$、$H_{AB}=-12k^4g_{AB}$。
代入 $G_{AB}+\Lambda_5g_{AB}+\alpha H_{AB}=0$：

$$
\boxed{k^2-2\alpha k^4=-\frac{\Lambda_5}{6}}.
$$

令 $u=k^2$，则

$$
u_\pm=\frac{1\pm\sqrt{1+\frac43\alpha\Lambda_5}}{4\alpha}.
$$

$u_-$ 在 $\alpha\to0$ 回到 $-\Lambda_5/6$；另一 branch 无平滑 Einstein limit。根号为实数、$u>0$ 只是背景存在条件的一部分，不是全部 stability conditions。

Brane junction conditions 与 graviton kinetic normalization 也会改变。加入 GB 后不能无条件使用 Einstein–RS 的 tension tuning 或 Planck integral；一般 supersymmetric curvature-squared correction 也不等于纯 GB 项。

## 10. Product backgrounds：维数相同，几何不同

### 10.1 Pure Einstein 加 cosmological constant 为什么不够？

analytic_derivation：五维纯 Einstein vacuum 要求

$$
R_{AB}=\frac23\Lambda_5g_{AB}.
$$

直接乘积的各因子必须有相同 Einstein constant。但

$$
\begin{aligned}
AdS_3:\;&R_{ab}=-\frac2{\ell_3^2}g_{ab},
& S^2:\;&R_{ij}=+\frac1{r_2^2}g_{ij},\\
AdS_4:\;&R_{\mu\nu}=-\frac3{\ell_4^2}g_{\mu\nu},
& S^1:\;&R_{\theta\theta}=0.
\end{aligned}
$$

有限半径下，前一组符号相反，后一组一负一零，都不能满足共同的 $\frac23\Lambda_5$。这个结论限定于 **unwarped direct product、pure Einstein–$\Lambda$ vacuum**；加入 matter、GB、warping 或 sources 后需另行判断。

### 10.2 Magnetic flux 支撑 $AdS_3\times S^2$

source_claim：它常出现为五维 magnetic black string 的 near-horizon geometry，用于 black-string entropy 与 $AdS_3/CFT_2$。具体 supersymmetric theory 可能含多个 gauge fields、scalars 和 Chern–Simons terms。[Castro et al.，5D Black Holes and Strings with Higher Derivatives](https://arxiv.org/abs/hep-th/0703087)

下面给出独立的 Einstein–Maxwell toy example：

$$
S=\frac1{16\pi G_5}\int d^5x\sqrt{-g}
\left(R-2\Lambda_5-\frac14F^2\right),
$$

$$
ds_5^2=ds^2_{AdS_3(\ell_3)}+r_2^2d\Omega_2^2,
\qquad F=q\sin\vartheta\,d\vartheta\wedge d\varphi.
$$

$\vartheta,\varphi$ 是无量纲 sphere angles，$F^2=2q^2/r_2^4$。
此归一化的 trace-reversed equation 为

$$
R_{AB}=\frac23\Lambda_5g_{AB}
+\frac12F_{AC}F_B{}^C-\frac1{12}g_{AB}F^2.
$$

analytic_derivation：AdS directions 上 Maxwell field 为零；sphere directions 有
$F_{ik}F_j{}^k=(q^2/r_2^4)g_{ij}$。因此

$$
-\frac2{\ell_3^2}=\frac23\Lambda_5-\frac{q^2}{6r_2^4},
\qquad
\frac1{r_2^2}=\frac23\Lambda_5+\frac{q^2}{3r_2^4}.
$$

特别地，$\Lambda_5=0$ 给出

$$
\boxed{r_2^2=\frac{q^2}{3},\qquad \ell_3=2r_2}.
$$

同一 magnetic field 对 internal 和 external directions 产生不同 stress，使两个因子有不同曲率。这是 local background calculation，不证明一定存在满足指定 asymptotics 的完整 black string。

固定 radius、Einstein approximation 下，$G_3=G_5/(4\pi r_2^2)$。若包含 radius fluctuations、warping 或 higher-curvature terms，低维 action 应重新求取。

### 10.3 $AdS_4\times S^1$ 需要何种支撑？

它是四维 AdS 与 circle 的 product compactification，需要额外 stress 与 radius stabilization。Circle 没有供 Maxwell two-form 穿过的二维 cycle；constant Wilson line 的 $F=0$，本身也不提供所需 local stress。

analytic_derivation：一个支撑例子是具有 shift symmetry 的 periodic scalar $\chi$：

$$
S=\frac1{16\pi G_5}\int d^5x\sqrt{-g}
\left[R-2\Lambda_5-\frac12(\partial\chi)^2\right],
$$

$$
ds_5^2=ds^2_{AdS_4(\ell_4)}+R_c^2d\theta^2,\qquad \chi=p\theta.
$$

$\theta\sim\theta+2\pi$。Global consistency 要求 $2\pi p$ 是 scalar period 的整数倍；若 $\chi$ 是 noncompact、single-valued scalar，就不能直接采用此 winding ansatz。

由 $R_{AB}=\frac23\Lambda_5g_{AB}
+\frac12\partial_A\chi\,\partial_B\chi$，
两个方向分别给出

$$
-\frac3{\ell_4^2}=\frac23\Lambda_5,\qquad
0=\frac23\Lambda_5+\frac{p^2}{2R_c^2}.
$$

所以当 $\Lambda_5<0$，

$$
\boxed{\ell_4^2=-\frac9{2\Lambda_5},\qquad
R_c^2=-\frac{3p^2}{4\Lambda_5}}.
$$

这是明确的 matter-supported product example，不是原始 RS，也不自动证明所有 radius modes 稳定。

source_claim：更丰富的 supergravity / string construction 包含 circle duality twist 与 S-fold；可能有 varying scalars 和 warping。因此记号 $AdS_4\times S^1$ 有时首先指 topology，不保证 fields 都是简单 constant product。[Arav et al.，AdS4 S-folds](https://arxiv.org/abs/2101.07264)

### 10.4 AdS brane 与 AdS product 是两回事

source_claim：Karch–Randall model 是 $AdS_4$ brane 嵌入 $AdS_5$ 的 warped setup；轻而有质量的 graviton 在适当尺度范围内可模拟四维引力。它不是 $AdS_4\times S^1$ direct product。[Karch–Randall，Locally Localized Gravity](https://arxiv.org/abs/hep-th/0011156)

## 11. AdS/CFT：连接几何与低维场论

source_claim：Anti-de Sitter / Conformal Field Theory correspondence（AdS/CFT）联系 $AdS_{d+1}$ quantum gravity 与 $d$ 维 boundary quantum field theory。经典例子是 type IIB string theory on $AdS_5\times S^5$ 与四维 $\mathcal N=4$ super Yang–Mills theory。Classical gravity approximation 要求适当的 large-$N$、strong-coupling 与小 bulk curvature regime。[Maldacena，AdS/CFT 原始 proposal](https://arxiv.org/abs/hep-th/9711200)

<strong>不要混淆两次“降维”：</strong>在 $S^5$ 上 KK reduction 得到五维 bulk theory；从 $AdS_5$ 到四维 boundary theory 则是 holographic duality。前者按 internal modes 重写自由度，后者把整个 bulk quantum theory 用 boundary variables 描述。

### 11.1 Radial coordinate 与 RG scale

analytic_derivation：Poincaré AdS 在
$(x^\mu,z)\mapsto(sx^\mu,sz)$ 下保持 metric invariant。由此获得直观的 energy–radius relation：

$$
\mu\sim z^{-1}.
$$

$z\to0$ 对应 UV，较大 $z$ 对应 IR；比例系数依坐标与 normalization 而定。Radial coordinate 的 renormalization-group（RG）解释属于 holographic interpretation，不等于普通空间维度的 compactification。

source_claim：RS 的 UV brane 可对应 ultraviolet cutoff 与 dynamical gravity；RS1 的 IR brane 对应 infrared conformal-symmetry breaking / mass scale；RS2 可用 cutoff CFT coupled to gravity 解释。具体 dual field theory 依 completion 和 fields 而定。[Arkani-Hamed, Porrati and Randall，Holography and Phenomenology](https://arxiv.org/abs/hep-th/0012148)

### 11.2 最基本的 scalar dictionary

source_claim：Euclidean generating-functional relation 示意为

$$
Z_{\rm bulk}[\Phi|_{\partial}=J]\simeq e^{-S_{\rm ren,on-shell}[J]}
=Z_{\rm CFT}[J],
\qquad
Z_{\rm CFT}[J]=\left\langle e^{\int d^dx\,J\mathcal O}\right\rangle.
$$

这里 boundary value 指适当 rescaling 后的 source coefficient；$S_{\rm ren,on-shell}$ 包含 boundary counterterms。Correlators 来自 source functional derivatives。[Witten，correlators 与 operator dimensions](https://arxiv.org/abs/hep-th/9802150)

analytic_derivation：$AdS_{d+1}$ 上 mass 为 $m$ 的 scalar，其 near-boundary radial equation 为

$$
z^2\Phi''-(d-1)z\Phi'-m^2\ell^2\Phi\simeq0.
$$

设 $\Phi\sim(z/\ell)^s$，得

$$
s(s-d)=m^2\ell^2,\qquad
\Delta_\pm=\frac d2\pm\sqrt{\frac{d^2}{4}+m^2\ell^2}.
$$

所以

$$
\Phi\sim(z/\ell)^{\Delta_-}J_b(x)+(z/\ell)^{\Delta_+}B(x)+\cdots,
\qquad m^2\ell^2=\Delta(\Delta-d).
$$

在 standard quantization 中，operator dimension 是 $\Delta_+$，$J_b$ 是 bulk source coefficient，$B$ 与 expectation value 相关；其比例因子与 contact terms 由 action normalization 和 renormalization 决定，不能普遍写成 $\langle\mathcal O\rangle=B$。

本文 bulk scalar $\Phi$ 使用统一引力前因子，可取为无量纲，因而 $J_b,B$ 无量纲；QFT normalization 中 $[J]=\mathrm{length}^{\Delta-d}$。二者需要 powers of $\ell$ 与 action-dependent normalization 映射，例如可写 $J=\mathcal N_J\ell^{\Delta-d}J_b$，其中 $\mathcal N_J$ 为 normalization constant；不能把两个 source 的单位直接混同。上面的 generating functional 示意式已经隐含这一 source mapping。

source_claim：Breitenlohner–Freedman（BF）bound 为
$m^2\ell^2\ge-d^2/4$；AdS 中某些 negative mass-squared scalars 仍可稳定。该条件讨论 linear scalar dynamics 与适当 boundary conditions，不是全体系稳定性证明。根号为实数只是局部检查。[Witten，scalar dimensions 与 negative mass-squared](https://arxiv.org/abs/hep-th/9802150)

例如 $AdS_5$ 有 $d=4$；$m^2\ell^2=-3$ 时两根为 $1,3$。$AdS_4$ 有 $d=3$；$m^2\ell^2=-2$ 时两根为 $1,2$。整数根差不自动要求 logarithmic term；是否出现 log 需检查完整 Frobenius recurrence、boundary condition 和 interactions。

### 11.3 Gravity dimension 与 CFT dimension

| Bulk external factor | 相应 conformal boundary dimension |
|---|---|
| $AdS_5$，如 RS bulk 局部几何 | 四维；RS branes 引入 cutoff 与 dynamical ingredients。 |
| $AdS_3$，如 $AdS_3\times S^2$ | 二维；$S^2$ internal modes 编码 operator content 等信息。 |
| $AdS_4$，如 $AdS_4\times S^1$ | 三维；circle reduction 后的 gravity 本身是四维。 |

“得到四维 gravity”与“dual CFT 是四维”是不同的维数陈述。

## 12. Black holes、cosmology 与 phenomenology

### 12.1 Brane black holes：bulk 与 brane 的分工

source_claim：对 Einstein bulk、体中仅有 $\Lambda_5$ 与 $Z_2$ symmetric brane，膜上有效方程为

$$
G_{\mu\nu}=-\Lambda_4h_{\mu\nu}+8\pi G_4T_{\mu\nu}
+\kappa_5^4\Pi_{\mu\nu}-E_{\mu\nu},
\qquad \kappa_5^2=8\pi G_5.
$$

$T_{\mu\nu}$ 是除 tension 外的 brane matter，$\Pi_{\mu\nu}$ 是 quadratic correction，$E_{\mu\nu}$ 是 bulk Weyl tensor 的 electric projection。[Shiromizu–Maeda–Sasaki，effective brane equations](https://arxiv.org/abs/gr-qc/9910076)

$E_{\mu\nu}$ 一般不能仅由 brane-local data 确定。看似四维 charged black-hole metric 的参数可能代表 bulk tidal effects，不能只凭 metric 形式解释为 Maxwell charge。加入 EMD bulk matter 或 GB 后，上式需修改。

### 12.2 不同问题对应的结构

| 研究问题 | 优先考虑的结构 |
|---|---|
| Electroweak hierarchy、spin-2 resonances、radion | RS1 与 stabilization；masses 和 couplings 依 model parameters。 |
| Long-distance gravity 与 infinite extra dimension | RS2 zero mode 与 continuum corrections。 |
| Higher-dimensional solution generation | Circle KK uplift / reduction 与特定 EMD coupling。 |
| Charged scalar dynamics、holographic matter | 指定 $f(\phi),V(\phi)$ 的 EMD，检查 asymptotics 与 boundary data。 |
| Curvature corrections、branches、entropy | EGB 或明确指定的 higher-derivative theory。 |
| Magnetic strings、Bañados–Teitelboim–Zanelli（BTZ）sectors | $AdS_3\times S^2$ 与支撑它的 flux / matter。 |
| Four-dimensional AdS effective theory | $AdS_4\times S^1$ 的支撑、radius stabilization 与 retained fields。 |

source_claim：RS2 cosmological extension 中，高能密度可产生 Friedmann equation 的 $\rho^2$ correction 和 bulk-related dark radiation；需要指定 cosmological ansatz，不从静态 flat-brane metric 自动得到。[Hebecker and March-Russell，RSII Cosmology, AdS/CFT, and the Bulk Black Hole](https://arxiv.org/abs/hep-ph/0103214)

hypothesis：具体 brane scalarization 项目中，EMD coupling、radion dynamics 或 GB 可能改变 scalar instability threshold；必须先冻结 action、background、boundary conditions 和 perturbation sector 再计算。本文不把这种可能性作为已有结果，也不把它变成原项目当前 numerical task 的前置门槛。

## 13. 常见混淆与约定差异

1. **$AdS_5$ 不等于 $AdS_4\times S^1$。** 前者 constant curvature，后者两个因子曲率不同。
2. **RS brane 不自动是 conformal boundary。** 有限 radial position 的 UV brane 是 cutoff surface；tension、matter 与 gravity terms 要独立指定。
3. **KK modes 不要求 compact internal space。** RS2 有 continuum KK modes。
4. **EMD dilaton 不自动是 radion。** 一个可能是 fundamental bulk scalar，另一个来自 geometry；识别须依据 reduction action。
5. **GB 不等于任意 scalar–curvature coupling。** $f(\phi)\mathcal G$ 与 constant $\alpha\mathcal G$ 的动力学不同。
6. **Background 存在不等于 compactification 稳定。** Radius、shape 与其他 modes 需单独检查；AdS negative mass-squared 需满足相应 BF bound。
7. **KK truncation 不自动 consistent。** Retained fields 不应源出 discarded modes；zero-mode bookkeeping 不代替此检查。
8. **AdS background 不自动给出已知完整 CFT dual。** Holographic interpretation 与 microscopic identification 是不同证据等级。
9. **Source exponent 不总是 operator dimension。** Standard quantization 中 source falloff 为 $d-\Delta$；特殊 masses 与 alternative quantization 要另述。
10. **Compile success 不是物理证明。** PDF 检查负责呈现，Mathematica/xAct 检查明确范围的公式，完整模型仍有独立证据要求。

## 14. 建议练习与答案

### 练习一：RS hierarchy

取 $m_0=10^{18}\,\mathrm{GeV}$、$m_{\rm 4D}=10^3\,\mathrm{GeV}$，求 $kL$ 并检查量纲。

答案：$kL=\ln(10^{15})\simeq34.54$；
$[k]=\mathrm{length}^{-1}$、$[L]=\mathrm{length}$。
这只是 mass-ratio 示例，不是 experimental constraints 的最佳拟合。

### 练习二：RS1 graviphoton parity

Reflection 如何作用于 $dx^\mu dy$？

答案：$dy\mapsto-dy$；保持 line element invariant 要求
$g_{\mu y}(x,-y)=-g_{\mu y}(x,y)$。
Constant vector zero mode 不满足 odd condition，被 projection 去掉。

### 练习三：product-vacuum obstruction

$\Lambda_5<0$、没有 matter 时，为什么 $AdS_4\times S^1$ 不成立？

答案：circle equation 左边为零，右边为非零 $\frac23\Lambda_5g_{\theta\theta}$；只满足 AdS directions 不够。

### 练习四：constant EMD scalar

$f=e^{-a\phi}$、$V=0$、$a\ne0$ 时，能否取 nonzero pure magnetic field 与 constant $\phi$？

答案：scalar equation 要求 $f'F^2=0$；pure magnetic field 的 $F^2>0$ 且 $f'\ne0$，所以 ansatz 不成立。适当 $V$、不同 field configuration 或 varying scalar 可能解除 obstruction。

### 练习五：operator dimension

$AdS_4$ 中 $m^2\ell^2=-2$，求 falloff exponents。

答案：$d=3$，$\Delta_-=1$、$\Delta_+=2$。
Standard quantization 有 $\Delta=2$，source falloff 为 $z^{d-\Delta}=z$。
两个 roots 不足以决定是否有 log。

### 练习六：GB Einstein branch

为什么 $u_-$ 有 Einstein limit，而 $u_+$ 没有？

答案：

$$
\sqrt{1+\frac43\alpha\Lambda_5}
=1+\frac23\alpha\Lambda_5+\mathcal O(\alpha^2).
$$

所以 $u_-=-\Lambda_5/6+\mathcal O(\alpha)$，
$u_+=1/(2\alpha)+\mathcal O(1)$。
这仅验证 limit，不证明 perturbative stability。

## 15. 证据、来源与核验范围

### 15.1 Evidence types

- <strong>source_claim：</strong>完整 KK reduction、RS spectrum、junction conditions、duality、phenomenology 与文献完整 solutions；各节给出 primary-source links。
- <strong>analytic_derivation：</strong>coordinate transformation、scalar normalization、Planck integral、Einstein-frame factors、curvature contractions、product obstruction、两个 toy backgrounds 与 scalar indicial polynomial。
- <strong>numerical_evidence：</strong>本文不提供 numerical black-hole solutions、stability scan 或 experimental fits。指数示例与图示不承担存在性和稳定性证明。
- <strong>hypothesis：</strong>第 12 节研究方向尚未成为任何项目已确认结论。

本文整体为 concept synthesis；frontmatter 的 verified 仅表示列出的局部数学检查已通过与来源可追溯，不表示全部 source_claim 获独立证明。Mathematica 15.0 与 xTensor 已完成 28 项 exact checks，全部通过；只有 checks/ 列出的等式和假设范围标为 verified；来源陈述不因排版或软件化简变成独立证明。

### 15.2 Primary sources 与定位

1. [Randall and Sundrum, A Large Mass Hierarchy from a Small Extra Dimension](https://arxiv.org/abs/hep-ph/9905221)：set-up、metric、Planck scale、mass redshift 与 phenomenology。
2. [Randall and Sundrum, An Alternative to Compactification](https://arxiv.org/abs/hep-th/9906064)：zero mode、continuum modes 与 Newton potential。
3. [Goldberger and Wise, Modulus Stabilization with Bulk Fields](https://arxiv.org/abs/hep-ph/9907447)：bulk scalar 与 radion potential。
4. [Lü, Mao and Wu, Asymptotic Structure of Einstein-Maxwell-Dilaton Theory and Its Five Dimensional Origin](https://arxiv.org/abs/1909.00970)：EMD Lagrangian Eq. (1)、uplift Eq. (60)；本文用 $\phi\mapsto-\phi$ 对齐 exponent signs。
5. [Lee, Gauss-Bonnet interaction in Randall-Sundrum compactification](https://arxiv.org/abs/hep-th/0010193)：GB–RS branches；本文 $\alpha$ 为 dimensionful coupling，需映射 normalization。
6. [Castro, Davis, Kraus and Larsen, 5D Black Holes and Strings with Higher Derivatives](https://arxiv.org/abs/hep-th/0703087)：magnetic-string near-horizon geometry；supersymmetric action 不等于本文 toy EM action。
7. [Arav et al., A new family of AdS4 S-folds in type IIB string theory](https://arxiv.org/abs/2101.07264)：circle monodromy 与 higher-dimensional completion。
8. [Karch and Randall, Locally Localized Gravity](https://arxiv.org/abs/hep-th/0011156)：$AdS_4$ brane in $AdS_5$。
9. [Maldacena, The Large N Limit of Superconformal Field Theories and Supergravity](https://arxiv.org/abs/hep-th/9711200)：AdS/CFT proposal。
10. [Witten, Anti De Sitter Space And Holography](https://arxiv.org/abs/hep-th/9802150)：correlators、masses 与 operator dimensions。
11. [Arkani-Hamed, Porrati and Randall, Holography and Phenomenology](https://arxiv.org/abs/hep-th/0012148)：cutoff CFT 与 dynamical gravity。
12. [Shiromizu, Maeda and Sasaki, The Einstein Equations on the 3-Brane World](https://arxiv.org/abs/gr-qc/9910076)：effective brane equations 与 projected Weyl tensor。
13. [Hebecker and March-Russell, Randall-Sundrum II Cosmology, AdS/CFT, and the Bulk Black Hole](https://arxiv.org/abs/hep-ph/0103214)：cosmological extension。

来源链接与 web metadata 核对日期：2026-09-30。只有明确列出的 source equation numbers 使用原文编号；未声称逐式重新验证所有 cited papers。

## 16. 开放问题、相关笔记与移植说明

### 16.1 Optional study

hypothesis / optional study：

1. 完整推导 circle reduction 的 scalar kinetic term 与 total derivatives。
2. 求解 RS tensor perturbation 的 Schrödinger problem，比较 bound state 与 continuum。
3. 求 toy backgrounds 的 radius-mode potential，检查 BF bounds。
4. 学习 holographic renormalization 的 source、response、counterterms 与 logarithmic terms。
5. 具体 black-hole problem 中，先明确 bulk / brane action、embedding、normal conventions 与 boundary conditions，再建立 numerical task。

这些是学习方向，不是本次笔记或原项目现有 task 的完成门槛。

### 16.2 与已有概念笔记的联系

参考项目中的 Frobenius method 笔记帮助理解第 11 节 indicial roots 与 logarithmic terms；Gauss hypergeometric function 笔记帮助理解 BTZ perturbations 与可解析 radial equations。本文借用其规范和模板，不引用原项目未核验的 black-hole 结果。

### 16.3 Portable artifacts

目录含 Markdown、shareable PDF、单文件 LaTeX source 和局部核验记录。LaTeX 内嵌图示、目录与参考链接，不使用原项目绝对路径、外部图片、custom class 或独立 bibliography file。XeLaTeX 编译两遍；默认 Fandol 字体，保留参考讲义 A4、字号、边距、配色、页眉页脚与独立封面。核验与 layout check 见 checks/verification.md。

